# AI real-estate web search

The mobile app calls the read-only endpoint configured in `lib/direct_feed.dart`:

`https://algouda-riyadh-offers.confidentchrysanthemum4.chatgpt.site/offers`

The Site Worker uses the OpenAI Responses API with its hosted `web_search` tool. Configure `OPENAI_API_KEY` as a secret on the Worker host; never put it in Flutter assets, source, or the APK. The server is rate-limited to one fresh search per hour and caches the result during that hour.

The search is limited to public web pages from Aqar, Haraj, Bayut, Wasalt, and Deal. It returns original ad links and only includes explicit owner/direct-agent claims or a likely owner when the public account page shows one or two ads. It does not log into private accounts, message advertisers, or guarantee complete platform coverage. A seller label is a text/profile-based estimate, not proof of ownership.

Required Worker secret:

- `OPENAI_API_KEY`

Set it in the Site runtime environment as a secret, then deploy the saved Worker version. OpenAI API usage is billed separately from ChatGPT Plus.
