package com.algouda.algouda_real_estate;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;
import androidx.core.app.NotificationCompat;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

public final class WhatsAppNotifications extends NotificationListenerService {
    static final String CHANNEL = "whatsapp_inbox";
    static final int INBOX_ALERT = 4001;

    @Override public void onListenerConnected() {
        if (WhatsAppInbox.enabledSince(this) == 0) return;
        StatusBarNotification[] active = getActiveNotifications();
        if (active == null) return;
        for (StatusBarNotification notice : active) onNotificationPosted(notice);
    }

    static boolean alertAllowed(Context context) {
        NotificationManager manager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 33 &&
                context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        if (Build.VERSION.SDK_INT >= 24 && !manager.areNotificationsEnabled()) return false;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = manager.getNotificationChannel(CHANNEL);
            return channel == null || channel.getImportance() != NotificationManager.IMPORTANCE_NONE;
        }
        return true;
    }

    @Override public void onNotificationPosted(StatusBarNotification posted) {
        String app = posted.getPackageName();
        if (!app.equals("com.whatsapp") && !app.equals("com.whatsapp.w4b")) return;
        long since = WhatsAppInbox.enabledSince(this);
        if (since == 0 || Build.VERSION.SDK_INT < 24) return;
        Notification notice = posted.getNotification();
        if ((notice.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        NotificationCompat.MessagingStyle style =
                NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(notice);
        if (style == null) return;

        String title = clean(style.getConversationTitle());
        boolean group = !title.isEmpty() && style.isGroupConversation();
        String thread = title;
        if (group && Build.VERSION.SDK_INT >= 26 && notice.getShortcutId() != null) {
            thread = notice.getShortcutId();
        }
        String groupKey = group ? fingerprint(app, thread) : "";

        List<ContentValues> rows = new ArrayList<>();
        for (NotificationCompat.MessagingStyle.Message message : style.getMessages()) {
            String sender = message.getPerson() == null ? "" : clean(message.getPerson().getName());
            String body = clean(message.getText());
            long time = message.getTimestamp();
            if (sender.isEmpty() || body.isEmpty() || time < since) continue;
            ContentValues row = new ContentValues();
            row.put("id", fingerprint(app, group ? groupKey : sender,
                    sender, Long.toString(time), body));
            row.put("body", body);
            row.put("sender", sender);
            row.put("source", group ? title : "محادثة خاصة");
            row.put("group_key", groupKey);
            row.put("happened", time);
            rows.add(row);
        }
        if (rows.isEmpty()) return;

        WhatsAppInbox.WORKER.execute(() -> {
            if (WhatsAppInbox.enabledSince(this) != since) return;
            try (WhatsAppInbox inbox = new WhatsAppInbox(this)) {
                if (inbox.add(rows, since) > 0) postAlert();
            } catch (RuntimeException error) {
                Log.w("AlgoudaInbox", "Could not capture WhatsApp notification", error);
            }
        });
    }

    private void postAlert() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                    new NotificationChannel(CHANNEL, "رسائل واتساب الجديدة", NotificationManager.IMPORTANCE_DEFAULT));
        }
        if (!alertAllowed(this)) return;
        Intent open = new Intent(this, NotificationActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent action = PendingIntent.getActivity(this, INBOX_ALERT, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        manager.notify(INBOX_ALERT, builder
                .setContentTitle("الجودة العقارية")
                .setContentText("وصلت رسائل واتساب جديدة جاهزة للفرز")
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentIntent(action)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .build());
    }

    private static String clean(CharSequence value) {
        return value == null ? "" : value.toString().trim();
    }

    private static String fingerprint(String... parts) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            for (String part : parts) {
                digest.update(part.getBytes(StandardCharsets.UTF_8));
                digest.update((byte) 0);
            }
            StringBuilder hex = new StringBuilder(64);
            for (byte value : digest.digest()) {
                hex.append(Character.forDigit((value >>> 4) & 15, 16));
                hex.append(Character.forDigit(value & 15, 16));
            }
            return hex.toString();
        } catch (NoSuchAlgorithmException error) {
            throw new IllegalStateException(error);
        }
    }
}
