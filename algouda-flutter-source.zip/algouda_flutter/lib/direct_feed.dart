import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'repository.dart';

const riyadhZones = ['شمال الرياض', 'شرق الرياض', 'غرب الرياض', 'جنوب الرياض'];
const residenceTypes = ['فيلا', 'أرض', 'شقة', 'دور', 'فيلا بقيمة أرض'];
const industrialTypes = ['أرض صناعية', 'مستودع'];
const offerTypes = [...residenceTypes, ...industrialTypes];
const dealTypes = ['بيع', 'إيجار'];
const feedPlatforms = ['عقار', 'حراج', 'ديل', 'بيوت'];
const advertiserRoles = [
  'يذكر أنه المالك',
  'يذكر أنه وكيل مباشر',
  'مرجّح أنه مالك',
];
const _settingsKey = 'direct-feed-v1';
const _publishedFeed =
    'https://algouda-riyadh-offers.confidentchrysanthemum4.chatgpt.site/offers';

Uri? feedUri(String value) {
  final uri = Uri.tryParse(value.trim());
  return uri != null &&
          uri.scheme == 'https' &&
          uri.host.isNotEmpty &&
          uri.userInfo.isEmpty &&
          !uri.hasQuery &&
          !uri.hasFragment
      ? uri
      : null;
}

List<Map<String, dynamic>> parseDirectOffers(Object? data) {
  if (data is! List || data.length > 400) throw const FormatException('offers');
  final result = <Map<String, dynamic>>[];
  final urls = <String>{};
  for (final raw in data) {
    if (raw is! Map<String, dynamic>) continue;
    final uri = Uri.tryParse(raw['url'] is String ? raw['url'] as String : '');
    if (uri == null ||
        uri.scheme != 'https' ||
        !const ['kite.sa', 'www.kite.sa'].contains(uri.host) ||
        uri.userInfo.isNotEmpty ||
        uri.hasPort ||
        uri.hasQuery ||
        uri.hasFragment ||
        !RegExp(r'^/(?:en/|ar/)?listing/\d+/?$').hasMatch(uri.path) ||
        !feedPlatforms.contains(raw['platform']) ||
        !riyadhZones.contains(raw['zone']) ||
        !offerTypes.contains(raw['type']) ||
        !dealTypes.contains(raw['deal']) ||
        !advertiserRoles.contains(raw['role']) ||
        raw['title'] is! String ||
        raw['district'] is! String ||
        raw['notes'] is! String ||
        !urls.add(uri.toString())) {
      continue;
    }
    result.add({
      for (final key in [
        'title',
        'district',
        'zone',
        'type',
        'deal',
        'role',
        'role_reason',
        'platform',
        'notes',
      ])
        key: raw[key],
      'url': uri.toString(),
    });
  }
  return result;
}

class DirectFeed extends ChangeNotifier {
  DirectFeed(this.repository);
  final Repository repository;
  final http.Client _client = http.Client();
  List<Map<String, dynamic>> offers = [];
  Uri? url;
  bool busy = false, _disposed = false;
  String status = 'المزامنة غير مفعّلة';
  Timer? _timer;

  Future<void> start() async {
    try {
      final options = await repository.setting(_settingsKey);
      if (_disposed) return;
      if (options is Map<String, dynamic> && options['url'] is String) {
        url = feedUri(options['url'] as String);
        if (url != null) offers = parseDirectOffers(options['offers']);
      } else {
        url = Uri.parse(_publishedFeed);
      }
    } catch (_) {
      status = 'تعذر تحميل إعداد المزامنة';
    }
    if (_disposed) return;
    notifyListeners();
    _timer = Timer.periodic(const Duration(minutes: 10), (_) => refresh());
    await refresh();
  }

  Future<void> refresh() async {
    final endpoint = url;
    if (endpoint == null || busy || _disposed) return;
    busy = true;
    status = 'جاري تحديث عروض الملاك';
    notifyListeners();
    try {
      final request = http.Request('GET', endpoint)..followRedirects = false;
      request.headers['Accept'] = 'application/json';
      final response = await _client
          .send(request)
          .timeout(const Duration(seconds: 20));
      final bytes = <int>[];
      await for (final chunk in response.stream.timeout(
        const Duration(seconds: 15),
      )) {
        if (bytes.length + chunk.length > 1000000)
          throw const FormatException('size');
        bytes.addAll(chunk);
      }
      final payload = jsonDecode(utf8.decode(bytes));
      if (response.statusCode == 503 &&
          payload is Map<String, dynamic> &&
          payload['error'] == 'provider_not_configured') {
        status = 'الخادم منشور. مصدر الإعلانات لسه مش مفعّل.';
        return;
      }
      if (response.statusCode != 200) throw const FormatException('response');
      if (payload is! Map<String, dynamic> || payload['version'] != 1) {
        throw const FormatException('version');
      }
      final next = parseDirectOffers(payload['offers']);
      if (_disposed) return;
      await repository.save(_settingsKey, {
        'url': endpoint.toString(),
        'offers': next,
      });
      if (_disposed) return;
      offers = next;
      status = 'آخر مزامنة: ${offers.length} عرض متاح';
    } catch (_) {
      status = 'تعذّرت المزامنة. العروض المحفوظة ما زالت متاحة.';
    } finally {
      busy = false;
      if (!_disposed) notifyListeners();
    }
  }

  Future<void> configure(BuildContext context) async {
    if (busy) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(status)));
      return;
    }
    var value = url?.toString() ?? '';
    final submitted = await showDialog<String>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('المزامنة التلقائية'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(status),
                const SizedBox(height: 12),
                TextFormField(
                  initialValue: value,
                  onChanged: (text) => value = text,
                  keyboardType: TextInputType.url,
                  decoration: const InputDecoration(
                    labelText: 'رابط خادم العروض (HTTPS)',
                    hintText: 'https://…/offers',
                  ),
                ),
              ],
            ),
            actions: [
              if (url != null)
                TextButton(
                  onPressed: () => Navigator.pop(context, ''),
                  child: const Text('إيقاف'),
                ),
              FilledButton(
                onPressed: () => Navigator.pop(context, value.trim()),
                child: const Text('حفظ ومزامنة'),
              ),
            ],
          ),
    );
    if (_disposed || submitted == null || busy) return;
    final endpoint = feedUri(submitted);
    if (submitted.isNotEmpty && endpoint == null) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('أدخل رابط HTTPS صحيح لخادم العروض')),
        );
      }
      return;
    }
    final retained = endpoint == url ? offers : <Map<String, dynamic>>[];
    busy = true;
    try {
      await repository.save(_settingsKey, {
        'url': endpoint?.toString() ?? '',
        'offers': retained,
      });
      if (_disposed) return;
      url = endpoint;
      offers = retained;
      status = url == null ? 'المزامنة غير مفعّلة' : 'تم حفظ رابط المزامنة';
    } catch (_) {
      status = 'تعذر حفظ رابط المزامنة';
    } finally {
      busy = false;
      if (!_disposed) notifyListeners();
    }
    await refresh();
  }

  @override
  void dispose() {
    _disposed = true;
    _timer?.cancel();
    _client.close();
    super.dispose();
  }
}
