import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'repository.dart';

const riyadhZones = [
  'كل الرياض',
  'شمال الرياض',
  'شرق الرياض',
  'غرب الرياض',
  'جنوب الرياض',
  'غير محدد',
];
const residenceTypes = ['فيلا', 'أرض', 'شقة', 'دور', 'فيلا بقيمة أرض'];
const industrialTypes = ['أرض صناعية', 'مستودع'];
const offerTypes = [...residenceTypes, ...industrialTypes];
const dealTypes = ['بيع', 'إيجار'];
const feedPlatforms = ['عقار', 'حراج', 'ديل', 'بيوت', 'وصلت'];
const advertiserRoles = [
  'يذكر أنه المالك',
  'يذكر أنه وكيل مباشر',
  'مرجّح أنه مالك',
  'غير متحقق',
  'غير متحقق من التنبيه',
];
const aiSearchEndpoint =
    'https://algouda-riyadh-offers.confidentchrysanthemum4.chatgpt.site/offers';
String? _feedPlatform(Uri link) {
  if (link.scheme != 'https' || link.userInfo.isNotEmpty || link.hasPort)
    return null;
  const platforms = {
    'aqar.fm': 'عقار',
    'haraj.com.sa': 'حراج',
    'dealapp.sa': 'ديل',
    'wasalt.sa': 'وصلت',
    'wasalt.com': 'وصلت',
    'bayut.sa': 'بيوت',
  };
  for (final entry in platforms.entries) {
    if (link.host == entry.key || link.host.endsWith('.${entry.key}'))
      return entry.value;
  }
  return null;
}

Uri? feedUri(String value) {
  final uri = Uri.tryParse(value.trim());
  return uri != null &&
          uri.scheme == 'https' &&
          uri.host.isNotEmpty &&
          uri.userInfo.isEmpty &&
          !uri.hasQuery &&
          !uri.hasFragment
      ? uri
      : null;
}

List<Map<String, dynamic>> parseDirectOffers(Object? data) {
  if (data is! List || data.length > 400) throw const FormatException('offers');
  final result = <Map<String, dynamic>>[];
  final urls = <String>{};
  for (final raw in data) {
    if (raw is! Map<String, dynamic>) continue;
    final uri = Uri.tryParse(raw['url'] is String ? raw['url'] as String : '');
    if (uri == null ||
        uri.scheme != 'https' ||
        _feedPlatform(uri) == null ||
        uri.userInfo.isNotEmpty ||
        uri.hasPort ||
        uri.hasFragment ||
        !feedPlatforms.contains(raw['platform']) ||
        !riyadhZones.contains(raw['zone']) ||
        !offerTypes.contains(raw['type']) ||
        !dealTypes.contains(raw['deal']) ||
        !advertiserRoles.contains(raw['role']) ||
        raw['title'] is! String ||
        raw['district'] is! String ||
        raw['notes'] is! String ||
        !urls.add(uri.toString())) {
      continue;
    }
    result.add({
      for (final key in [
        'title',
        'district',
        'zone',
        'type',
        'deal',
        'role',
        'role_reason',
        'platform',
        'advertiser',
        'notes',
      ])
        key: raw[key],
      'url': uri.toString(),
    });
  }
  return result;
}

class DirectFeed extends ChangeNotifier {
  DirectFeed(this.repository);
  final Repository repository;
  List<Map<String, dynamic>> offers = [];
  Uri? url;
  bool busy = false, _disposed = false;
  String status = 'المزامنة غير مفعّلة';

  Future<void> start() async {
    url = null;
    if (_disposed) return;
    try {
      final previous = await repository.setting('ai-direct-offers-v2');
      if (previous is List) offers = parseDirectOffers(previous);
    } catch (_) {
      // A missing or stale local cache should not prevent a fresh search.
    }
    notifyListeners();
    await refresh();
  }

  Future<void> refresh() async {
    if (busy || _disposed) return;
    busy = true;
    status = 'وكيل الذكاء الاصطناعي يبحث في صفحات العقار العامة…';
    notifyListeners();
    try {
      final response = await http
          .get(
            Uri.parse(aiSearchEndpoint),
            headers: {'Accept': 'application/json'},
          )
          .timeout(const Duration(seconds: 100));
      final decoded = jsonDecode(utf8.decode(response.bodyBytes));
      if (decoded is! Map<String, dynamic>) {
        throw const FormatException('تعذر قراءة رد وكيل البحث');
      }
      if (response.statusCode != 200) {
        final error = decoded['error'];
        if (error == 'ai_key_not_configured') {
          throw const FormatException(
            'محرك البحث لم يتفعّل بعد على الخادم؛ يلزم إعداد مفتاح OpenAI API هناك.',
          );
        }
        if (error == 'search_rate_limited') {
          throw const FormatException(
            'البحث اتعمل قريب؛ انتظر ساعة ثم حدّث النتائج.',
          );
        }
        throw const FormatException('تعذر تشغيل بحث الذكاء الاصطناعي الآن.');
      }
      final next = parseDirectOffers(decoded['offers']);
      if (_disposed) return;
      offers = next;
      await repository.save('ai-direct-offers-v2', offers);
      status =
          offers.isEmpty
              ? 'البحث لم يعثر على إعلانات مؤكدة مطابقة حاليًا.'
              : 'اكتمل بحث الويب بالذكاء الاصطناعي: ${offers.length} إعلانًا. راجع الرابط الأصلي وصفة المعلن.';
    } on FormatException catch (error) {
      status = error.message;
    } catch (_) {
      status =
          offers.isEmpty
              ? 'تعذر الاتصال بمحرك البحث. تحقق من الإنترنت وإعداد الخدمة.'
              : 'تعذر تحديث البحث؛ المعروض آخر نتائج محفوظة على الهاتف.';
    } finally {
      busy = false;
      if (!_disposed) notifyListeners();
    }
  }

  Future<void> configure(BuildContext context) async {
    await showDialog<void>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('وكيل البحث بالذكاء الاصطناعي'),
            content: const Text(
              'التطبيق يطلب من وكيل سحابي البحث في صفحات الويب العامة لمنصات العقار، ثم يصنف النتائج ويعرض رابط الإعلان. البحث لا يدخل حساباتك ولا يثبت الملكية. بعض المنصات قد لا تظهر نتائجها أو تمنع الوصول. يلزم إعداد مفتاح OpenAI API على الخادم، ولا تضعه داخل التطبيق أو ترسله في المحادثة.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('إغلاق'),
              ),
            ],
          ),
    );
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}
