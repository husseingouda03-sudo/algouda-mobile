import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'direct_feed.dart';
import 'messages.dart';
import 'repository.dart';
import 'riyadh_research.dart';

const listingPlatforms = {
  'aqar.fm': 'عقار',
  'haraj.com.sa': 'حراج',
  'dealapp.sa': 'ديل',
  'wasalt.sa': 'وصلت',
  'wasalt.com': 'وصلت',
  'bayut.sa': 'بيوت',
};

String? listingPlatform(Uri link) {
  if (link.scheme != 'https' || link.userInfo.isNotEmpty || link.hasPort)
    return null;
  for (final entry in listingPlatforms.entries) {
    if (link.host == entry.key || link.host.endsWith('.${entry.key}'))
      return entry.value;
  }
  return null;
}

String? saudiMobile(String value) {
  final number = digits(value).replaceAll(RegExp(r'[+\s()\-]'), '');
  if (RegExp(r'^05\d{8}$').hasMatch(number)) return '966${number.substring(1)}';
  if (RegExp(r'^9665\d{8}$').hasMatch(number)) return number;
  if (RegExp(r'^009665\d{8}$').hasMatch(number)) return number.substring(2);
  return null;
}

class DirectOffersPage extends StatefulWidget {
  const DirectOffersPage({super.key, required this.repository});
  final Repository repository;

  @override
  State<DirectOffersPage> createState() => _DirectOffersPageState();
}

class _DirectOffersPageState extends State<DirectOffersPage> {
  static const storageKey = 'direct-listings-v1';
  List<Map<String, dynamic>> saved = [];
  bool loaded = false, writing = false, buyers = false;
  String zone = riyadhZones.first, deal = dealTypes.first, propertyType = '';
  String advertiserFilter = '';
  late final DirectFeed feed;
  String error = '';

  @override
  void initState() {
    super.initState();
    feed = DirectFeed(widget.repository)..addListener(feedChanged);
    feed.start();
    load();
  }

  void feedChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    feed.removeListener(feedChanged);
    feed.dispose();
    super.dispose();
  }

  Future<void> load() async {
    try {
      final stored = await widget.repository.setting(storageKey);
      if (!mounted) return;
      setState(() {
        saved =
            stored is List
                ? stored
                    .whereType<Map>()
                    .map((row) => Map<String, dynamic>.from(row))
                    .toList()
                : [];
        loaded = true;
        error = '';
      });
    } catch (_) {
      if (mounted) setState(() => error = 'تعذر فتح العروض المحفوظة.');
    }
  }

  Future<void> addOffer([Map<String, dynamic>? previous]) async {
    final entry = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (_) => _OfferForm(initial: previous, zone: zone, deal: deal),
    );
    if (!mounted || entry == null || writing) return;
    final match = saved.any(
      (row) => row['url'] == entry['url'] && row['url'] != previous?['url'],
    );
    if (match) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('الرابط محفوظ بالفعل')));
      return;
    }
    final updated = [
      for (final row in saved)
        if (row['url'] != previous?['url']) row,
      entry,
    ];
    setState(() => writing = true);
    try {
      await widget.repository.save(storageKey, updated);
      if (mounted) setState(() => saved = updated);
    } catch (_) {
      if (mounted)
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('تعذر حفظ العرض')));
    } finally {
      if (mounted) setState(() => writing = false);
    }
  }

  Future<void> open(Uri uri) async {
    try {
      if (await launchUrl(uri, mode: LaunchMode.externalApplication)) return;
    } catch (_) {
      // A device may have no app available for the link.
    }
    if (mounted)
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('تعذر فتح الرابط')));
  }

  Future<void> draft(Map<String, dynamic> offer) async {
    var draftText =
        'السلام عليكم، معك من الجودة العقارية. بخصوص إعلان ${offer['title']}، '
        'هل العرض ما زال متاحًا؟ وهل حضرتك المالك أو وكيله؟ '
        'لو مناسب لحضرتك، ممكن السعر الحالي والمساحة والموقع، وهل تسمح لنا بالتسويق؟';
    final message = await showDialog<String>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('راجع رسالة التواصل'),
            content: TextFormField(
              initialValue: draftText,
              onChanged: (value) => draftText = value,
              maxLines: 7,
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('إلغاء'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, draftText.trim()),
                child: const Text('فتح المسودة في واتساب'),
              ),
            ],
          ),
    );
    if (!mounted || message == null || message.isEmpty) return;
    await open(Uri.https('wa.me', textOf(offer, 'phone'), {'text': message}));
  }

  Future<void> searchPlatforms() async {
    final platform = await showDialog<String>(
      context: context,
      builder:
          (context) => SimpleDialog(
            title: const Text('ابحث في المنصات'),
            children: [
              for (final item in listingPlatforms.entries)
                if (item.key != 'wasalt.com')
                  SimpleDialogOption(
                    onPressed: () => Navigator.pop(context, item.key),
                    child: Text(item.value),
                  ),
            ],
          ),
    );
    if (!mounted || platform == null) return;
    final filter =
        buyers
            ? 'مطلوب شراء فيلا شقة أرض الرياض'
            : 'للبيع من المالك مباشرة الرياض';
    await open(
      Uri.https('www.google.com', '/search', {'q': 'site:$platform $filter'}),
    );
  }

  Future<void> copyOffer(Map<String, dynamic> entry) async {
    await Clipboard.setData(
      ClipboardData(
        text: [
          '${entry['title']} · ${entry['deal']}',
          '${entry['zone']} · حي ${entry['district']}',
          textOf(entry, 'notes'),
          textOf(entry, 'url'),
        ].where((line) => line.isNotEmpty).join('\n'),
      ),
    );
    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('تم نسخ مسودة العرض')));
    }
  }

  Widget card(Map<String, dynamic> entry) {
    final uri = Uri.tryParse(textOf(entry, 'url'));
    final source = textOf(entry, 'platform');
    final fromFeed = source.isNotEmpty;
    final platform =
        fromFeed
            ? '$source · عبر Kite'
            : uri == null
            ? null
            : listingPlatform(uri);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              textOf(entry, 'title'),
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 6),
            Text(
              [
                if (platform != null) platform,
                textOf(entry, 'district'),
              ].where((value) => value.isNotEmpty).join(' · '),
            ),
            if (textOf(entry, 'role').isNotEmpty) ...[
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 6,
                children: [
                  Chip(
                    avatar: Icon(
                      textOf(entry, 'role') == 'مرجّح أنه مالك'
                          ? Icons.help_outline
                          : Icons.info_outline,
                      size: 18,
                    ),
                    label: Text(textOf(entry, 'role')),
                  ),
                ],
              ),
              if (textOf(entry, 'role_reason').isNotEmpty)
                Text(
                  textOf(entry, 'role_reason'),
                  style: Theme.of(context).textTheme.bodySmall,
                ),
            ],
            if (textOf(entry, 'notes').isNotEmpty) ...[
              const SizedBox(height: 6),
              Text(textOf(entry, 'notes')),
            ],
            Wrap(
              spacing: 8,
              children: [
                if (uri != null && platform != null)
                  TextButton(
                    onPressed: () => open(uri),
                    child: const Text('افتح المصدر'),
                  ),
                if (!buyers && !fromFeed)
                  TextButton(
                    onPressed: writing ? null : () => addOffer(entry),
                    child: const Text('حفظ أو تعديل بيانات العرض'),
                  ),
                if (!buyers)
                  TextButton(
                    onPressed: () => copyOffer(entry),
                    child: const Text('انسخ مسودة العرض'),
                  ),
                if (!buyers && saudiMobile(textOf(entry, 'phone')) != null)
                  TextButton(
                    onPressed: () => draft(entry),
                    child: const Text('جهّز رسالة واتساب'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final urls = saved.map((row) => row['url']).toSet();
    final offers = [
      ...saved,
      ...feed.offers.where((row) => urls.add(row['url'])),
      ...riyadhOffers.where((row) => urls.add(row['url'])),
    ];
    final visible =
        offers
            .where(
              (row) =>
                  row['zone'] == zone &&
                  row['deal'] == deal &&
                  (advertiserFilter.isEmpty ||
                      row['role'] == advertiserFilter) &&
                  (propertyType.isEmpty || row['type'] == propertyType),
            )
            .toList();
    return Scaffold(
      appBar: AppBar(
        title: const Text('عروض مباشرة'),
        actions: [
          IconButton(
            onPressed: () => feed.configure(context),
            icon: const Icon(Icons.sync),
            tooltip: 'المزامنة التلقائية',
          ),
          IconButton(
            onPressed: searchPlatforms,
            icon: const Icon(Icons.travel_explore),
            tooltip: 'ابحث في المنصات',
          ),
        ],
      ),
      floatingActionButton:
          !loaded || buyers
              ? null
              : FloatingActionButton.extended(
                onPressed: writing ? null : addOffer,
                icon: const Icon(Icons.add),
                label: const Text('إضافة عرض'),
              ),
      body:
          error.isNotEmpty
              ? Center(child: TextButton(onPressed: load, child: Text(error)))
              : !loaded
              ? const Center(child: CircularProgressIndicator())
              : SafeArea(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 88),
                  children: [
                    Wrap(
                      spacing: 8,
                      children: [
                        ChoiceChip(
                          label: const Text('عروض الملاك'),
                          selected: !buyers,
                          onSelected: (_) => setState(() => buyers = false),
                        ),
                        ChoiceChip(
                          label: const Text('طلبات الشراء'),
                          selected: buyers,
                          onSelected: (_) => setState(() => buyers = true),
                        ),
                      ],
                    ),
                    if (buyers) ...[
                      const Text(
                        'الطلبات المنشورة في آخر بحث. التواصل من صفحة الطلب.',
                      ),
                      for (final entry in riyadhBuyers) card(entry),
                    ] else ...[
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 8,
                        children: [
                          for (final area in riyadhZones)
                            ChoiceChip(
                              label: Text(area),
                              selected: zone == area,
                              onSelected:
                                  (_) => setState(() {
                                    zone = area;
                                    propertyType = '';
                                  }),
                            ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      SegmentedButton<String>(
                        segments: const [
                          ButtonSegment(value: 'بيع', label: Text('بيع')),
                          ButtonSegment(value: 'إيجار', label: Text('إيجار')),
                        ],
                        selected: {deal},
                        onSelectionChanged:
                            (value) => setState(() => deal = value.single),
                      ),
                      const SizedBox(height: 10),
                      const Text('تصنيف المعلن'),
                      const SizedBox(height: 6),
                      const Text(
                        '«يذكر» يعني أن الإعلان أو بيانات الحساب تقول ذلك. «مرجّح» تقدير من عدد إعلانات الحساب الظاهرة في نتائج البحث فقط، وليس إثباتًا للملكية.',
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        children: [
                          ChoiceChip(
                            label: const Text('الكل'),
                            selected: advertiserFilter.isEmpty,
                            onSelected:
                                (_) => setState(() => advertiserFilter = ''),
                          ),
                          for (final role in advertiserRoles)
                            ChoiceChip(
                              label: Text(role),
                              selected: advertiserFilter == role,
                              onSelected:
                                  (_) =>
                                      setState(() => advertiserFilter = role),
                            ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 8,
                        children: [
                          for (final type in [
                            '',
                            ...residenceTypes,
                            if (zone == riyadhZones.last) ...industrialTypes,
                          ])
                            ChoiceChip(
                              label: Text(type.isEmpty ? 'كل الأنواع' : type),
                              selected: propertyType == type,
                              onSelected:
                                  (_) => setState(() => propertyType = type),
                            ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      if (visible.isEmpty)
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 16),
                          child: Text('مفيش عروض في الاختيار ده حاليًا.'),
                        ),
                      for (final type in offerTypes)
                        if (visible.any((entry) => entry['type'] == type)) ...[
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            child: Text(
                              type,
                              style: Theme.of(context).textTheme.titleMedium,
                            ),
                          ),
                          for (final entry in visible.where(
                            (row) => row['type'] == type,
                          ))
                            card(entry),
                        ],
                    ],
                  ],
                ),
              ),
    );
  }
}

class _OfferForm extends StatefulWidget {
  const _OfferForm({this.initial, required this.zone, required this.deal});
  final Map<String, dynamic>? initial;
  final String zone, deal;

  @override
  State<_OfferForm> createState() => _OfferFormState();
}

class _OfferFormState extends State<_OfferForm> {
  final form = GlobalKey<FormState>();
  final title = TextEditingController(),
      district = TextEditingController(),
      url = TextEditingController(),
      phone = TextEditingController(),
      notes = TextEditingController();
  String zone = riyadhZones.first,
      type = residenceTypes.first,
      role = 'المالك بحسب الإعلان',
      deal = 'بيع';

  @override
  void initState() {
    super.initState();
    zone = widget.zone;
    deal = widget.deal;
    final initial = widget.initial;
    if (initial == null) return;
    title.text = textOf(initial, 'title');
    district.text = textOf(initial, 'district');
    url.text = textOf(initial, 'url');
    phone.text = textOf(initial, 'phone');
    notes.text = textOf(initial, 'notes');
    zone = textOf(initial, 'zone');
    type = textOf(initial, 'type');
    role = textOf(initial, 'role');
    deal = textOf(initial, 'deal');
  }

  @override
  void dispose() {
    for (final controller in [title, district, url, phone, notes]) {
      controller.dispose();
    }
    super.dispose();
  }

  Widget choice(
    String label,
    String value,
    List<String> options,
    ValueChanged<String> change,
  ) => DropdownButtonFormField<String>(
    value: value,
    isExpanded: true,
    decoration: InputDecoration(labelText: label),
    items: [
      for (final item in options)
        DropdownMenuItem(value: item, child: Text(item)),
    ],
    onChanged: (value) {
      if (value != null) setState(() => change(value));
    },
  );

  Widget field(
    TextEditingController controller,
    String label, {
    String? Function(String?)? validate,
    TextInputType? keyboardType,
    int maxLines = 1,
  }) => Padding(
    padding: const EdgeInsets.only(top: 8),
    child: TextFormField(
      controller: controller,
      maxLines: maxLines,
      keyboardType: keyboardType,
      decoration: InputDecoration(labelText: label),
      validator: validate,
    ),
  );

  String? requiredText(String? value) =>
      value == null || value.trim().isEmpty ? 'مطلوب' : null;

  @override
  Widget build(BuildContext context) {
    final types = zone == riyadhZones.last ? offerTypes : residenceTypes;
    return AlertDialog(
      title: const Text('احفظ إعلان مالك أو وكيل'),
      content: Form(
        key: form,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              field(
                url,
                'رابط الإعلان',
                keyboardType: TextInputType.url,
                validate: (value) {
                  final uri = Uri.tryParse(value?.trim() ?? '');
                  return uri != null &&
                          listingPlatform(uri) != null &&
                          uri.pathSegments.isNotEmpty
                      ? null
                      : 'استخدم رابط الإعلان من عقار أو حراج أو ديل أو وصلت أو بيوت';
                },
              ),
              field(title, 'عنوان الإعلان', validate: requiredText),
              field(district, 'الحي', validate: requiredText),
              choice('المنطقة', zone, riyadhZones, (value) {
                zone = value;
                type = residenceTypes.first;
              }),
              choice('نوع العقار', type, types, (value) => type = value),
              choice('نوع العرض', deal, const [
                'بيع',
                'إيجار',
              ], (value) => deal = value),
              choice('صفة المعلن', role, const [
                'المالك بحسب الإعلان',
                'وكيل المالك بحسب الإعلان',
              ], (value) => role = value),
              field(
                phone,
                'رقم واتساب المعلن (اختياري)',
                keyboardType: TextInputType.phone,
                validate:
                    (value) =>
                        value == null ||
                                value.trim().isEmpty ||
                                saudiMobile(value) != null
                            ? null
                            : 'أدخل رقم جوال سعودي صحيح',
              ),
              field(notes, 'السعر والمساحة وتفاصيل العرض', maxLines: 3),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('إلغاء'),
        ),
        FilledButton(
          onPressed: () {
            if (form.currentState?.validate() != true) return;
            Navigator.pop(context, <String, dynamic>{
              'title': title.text.trim(),
              'district': district.text.trim(),
              'url': Uri.parse(url.text.trim()).toString(),
              'zone': zone,
              'role': role,
              'phone': saudiMobile(phone.text) ?? '',
              'notes': notes.text.trim(),
              'type': type,
              'deal': deal,
            });
          },
          child: const Text('حفظ العرض'),
        ),
      ],
    );
  }
}
