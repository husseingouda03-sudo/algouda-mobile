const providers = {aqar: 'عقار', haraj: 'حراج', deal: 'ديل', bayut: 'بيوت'};
const types = {
  villa: 'فيلا', duplex: 'فيلا', land: 'أرض',
  apartment: 'شقة', floor: 'دور', warehouse: 'مستودع',
};
const deals = {sale: 'بيع', rent: 'إيجار'};
const zones = new Set(['شمال الرياض', 'شرق الرياض', 'غرب الرياض', 'جنوب الرياض']);
const ttl = 30 * 60_000;
let cache, inflight, directions, directionsUntil = 0, retryAfter = 0;

const normalize = (value) => String(value ?? '').replace(/[أإآ]/g, 'ا').normalize('NFD').replace(/\p{M}/gu, '');
const advertiserKey = (row) => {
  const ad = row.advertiser ?? {};
  const value = ad.id ?? ad.account_id ?? ad.name ?? ad.name_en;
  const key = normalize(value).trim();
  return key || null;
};
const listingKey = (row) => String(row.id ?? row.listing_id ?? row.url ?? '');
const classifyAdvertiser = (row, counts) => {
  const ad = row.advertiser ?? {};
  const advertiserType = String(ad.type ?? '').toLowerCase();
  const text = normalize(`${row.title ?? ''} ${row.description ?? ''}`);
  const company = Boolean(ad.company || ad.cr) || /(?:^|\s)(شركة|مكتب|مؤسسة)(?=\s|$)/u.test(normalize(ad.name));
  const marketer = /وسيط عقاري|وسيط|مسوق عقاري|مسوق|تسويق عقاري/u.test(text);
  const ownerClaim = /انا المالك|انا مالك(?: العقار| هذا العقار)?|من المالك مباشرة|مباشرة من المالك|المالك مباشرة|بيع من المالك|البيع من المالك|مالك العقار مباشرة|صاحب العقار/u.test(text) ||
    ['individual_owner', 'owner'].includes(advertiserType);
  const agentClaim = /وكيل المالك|وكيل عن المالك|وكيل للمالك|وكيل مباشر|مفوض من المالك|بتفويض من المالك|نيابة عن المالك|بصفتي وكيل(?:ا|ة)? عن المالك/u.test(text);
  const refusesMarketing = /لا اسمح بالتسويق|لا اسمح بتسويق|لا اقبل التسويق/u.test(text);
  if (refusesMarketing) return null;
  if (ownerClaim && !company && !marketer) {
    return {role: 'يذكر أنه المالك', role_reason: 'الإعلان أو بيانات الحساب تذكر أن المعلن هو المالك'};
  }
  if (agentClaim && !company) {
    return {role: 'يذكر أنه وكيل مباشر', role_reason: 'نص الإعلان يذكر وكالة مباشرة عن المالك'};
  }
  const key = advertiserKey(row);
  const count = key ? counts.get(key) ?? 0 : 0;
  const knownIntermediary = company || marketer || ['company', 'individual_broker', 'company_broker', 'broker', 'agent'].includes(advertiserType) || Boolean(ad.fal_number);
  if (!knownIntermediary && count > 0 && count <= 2) {
    const label = count === 1 ? 'مرجّح: للحساب إعلان واحد ضمن النتائج' : 'مرجّح: للحساب إعلانان ضمن النتائج';
    return {role: 'مرجّح أنه مالك', role_reason: label};
  }
  return null;
};

function toOffer(row, districtZones, counts) {
  const classification = classifyAdvertiser(row, counts);
  if (!classification) return null;
  const location = row.location ?? {};
  const platform = Object.hasOwn(providers, row.source?.name) ? providers[row.source.name] : null;
  const deal = Object.hasOwn(deals, row.listing_type) ? deals[row.listing_type] : null;
  let type = Object.hasOwn(types, row.property_type) ? types[row.property_type] : null;
  const district = location.neighborhood_name_ar;
  const zone = districtZones.get(location.neighborhood_id);
  const url = row.url;
  if (!platform || !deal || !type || !district || !zone || location.city !== 'riyadh' ||
      typeof url !== 'string' || !/^https:\/\/(?:www\.)?kite\.sa\/(?:(?:ar|en)\/)?listing\/\d+\/?$/u.test(url)) return null;
  if (type === 'أرض' && row.plot?.zoning === 'industrial') type = 'أرض صناعية';
  if (['أرض', 'فيلا'].includes(type) &&
      /(?:فيلا|فل[هة]) بقيم[هة] ارض/u.test(normalize(`${row.title ?? ''} ${row.description ?? ''}`))) type = 'فيلا بقيمة أرض';
  if (['أرض صناعية', 'مستودع'].includes(type) && zone !== 'جنوب الرياض') return null;
  const price = row.price?.yearly_sar;
  const notes = [];
  if (Number.isFinite(price) && price > 0) {
    notes.push(`${price.toLocaleString('en-US')} ريال${deal === 'إيجار' ? ' سنويًا' : ''}`);
  }
  if (Number.isFinite(row.area_sqm) && row.area_sqm > 0) notes.push(`${row.area_sqm} م²`);
  return {
    title: `${type} · ${district}`.slice(0, 160),
    district: district.slice(0, 100), zone, type, deal,
    ...classification, platform, url, notes: notes.join(' · '),
  };
}

async function kite(key, path, query) {
  const url = new URL(`https://api.kite.sa/v1${path}`);
  if (query) url.search = new URLSearchParams(query).toString();
  let response;
  try {
    response = await fetch(url, {
      headers: {
        Authorization: `Bearer ${key}`,
        Accept: 'application/json',
        'User-Agent': 'AlgoudaRiyadhOffers/1.0',
      },
      // Keep redirects visible without forwarding the API key to another URL.
      redirect: 'manual',
      signal: AbortSignal.timeout(15_000),
    });
  } catch (cause) {
    const error = new Error('network_error');
    error.upstreamPath = path;
    error.networkType = cause?.name;
    error.networkCode = cause?.cause?.code;
    throw error;
  }
  const data = await response.json().catch(() => null);
  if (response.status >= 300 && response.status < 400) {
    const error = new Error('upstream_unavailable');
    error.upstreamPath = path;
    error.upstreamStatus = response.status;
    error.upstreamCode = 'unexpected_redirect';
    error.requestId = response.headers.get('x-request-id');
    throw error;
  }
  if (!response.ok) {
    const error = new Error('upstream_unavailable');
    error.upstreamPath = path;
    error.upstreamStatus = response.status;
    error.upstreamCode = data?.error?.code ?? data?.code ?? null;
    error.requestId = data?.request_id ?? response.headers.get('x-request-id');
    throw error;
  }
  if (!Array.isArray(data.data)) {
    const error = new Error('upstream_format');
    error.upstreamPath = path;
    throw error;
  }
  return data;
}

async function fetchDeal(mode, key) {
  const query = {
    city: 'riyadh', listing_type: mode, sort: 'newest',
    source: Object.keys(providers).join(','),
    property_type: Object.keys(types).join(','), limit: 25,
  };
  const page = await kite(key, '/listings', query);
  const cursor = page.pagination?.next_cursor;
  if (!cursor) return page.data;
  const next = await kite(key, '/listings', {...query, cursor});
  return [...page.data, ...next.data];
}

async function refresh(key) {
  const needsDirections = !directions || Date.now() >= directionsUntil;
  const [directionReply, rows] = await Promise.all([
    needsDirections ? kite(key, '/cities/riyadh/directions') : Promise.resolve(null),
    Promise.all(Object.keys(deals).map((mode) => fetchDeal(mode, key))).then((pages) => pages.flat()),
  ]);
  if (directionReply) {
    const next = new Map();
    for (const row of directionReply.data) {
      if (!zones.has(row.name_ar) || !Array.isArray(row.neighborhood_ids)) continue;
      for (const id of row.neighborhood_ids) next.set(id, row.name_ar);
    }
    if (!next.size) throw new Error('invalid_directions');
    directions = next;
    directionsUntil = Date.now() + 86_400_000;
  }
  const distinct = new Map();
  const advertiserListings = new Map();
  for (const row of rows) {
    const key = advertiserKey(row);
    if (!key) continue;
    const listing = listingKey(row);
    if (!listing) continue;
    if (!advertiserListings.has(key)) advertiserListings.set(key, new Set());
    advertiserListings.get(key).add(listing);
  }
  const advertiserCounts = new Map([...advertiserListings].map(([key, listings]) => [key, listings.size]));
  for (const row of rows) {
    const offer = toOffer(row, directions, advertiserCounts);
    if (offer && !distinct.has(offer.url)) distinct.set(offer.url, offer);
  }
  const data = {version: 1, offers: [...distinct.values()]};
  cache = {expires: Date.now() + ttl, data};
  return data;
}

const json = (body, status = 200, cacheControl = 'no-store') =>
  Response.json(body, {status, headers: {'Cache-Control': cacheControl}});

function home(configured) {
  const status = configured ? 'تم إعداد مصدر البيانات. التطبيق يتحقق من توفره عند المزامنة.' :
    'خادم المزامنة منشور. في انتظار تفعيل مصدر الإعلانات.';
  return new Response(`<!doctype html>
<html lang="ar" dir="rtl">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>عروض ملاك الرياض | الجودة العقارية</title>
<style>
body{margin:0;background:#eef6f1;color:#153828;font:1rem/1.8 system-ui,sans-serif}
main{max-width:36rem;margin:12vh auto;padding:2rem;border-radius:1.25rem;background:white}
h1{font-size:2rem;line-height:1.3;margin:0 0 .75rem} a{color:#075c44}
@media(max-width:40rem){main{margin:8vh 1rem;padding:1.5rem}}
</style>
<main><h1>عروض ملاك الرياض</h1><p>${status}</p>
<p>استخدم رابط المزامنة في قسم «عروض مباشرة» داخل تطبيق الجودة العقارية.</p>
<a href="/offers">رابط مزامنة العروض</a></main></html>`, {
    headers: {'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store'},
  });
}

export default {
  async fetch(request, env) {
    if (request.method !== 'GET') return json({error: 'method_not_allowed'}, 405);
    const {pathname} = new URL(request.url);
    const key = env.KITE_API_KEY;
    if (pathname === '/') return home(Boolean(key));
    if (pathname === '/health') return json({service: 'riyadh-owner-offers', provider_configured: Boolean(key)});
    if (pathname !== '/offers') return json({error: 'not_found'}, 404);
    if (!key) return json({error: 'provider_not_configured'}, 503);
    if (cache && Date.now() < cache.expires) return json(cache.data, 200, 'public, max-age=300');
    if (Date.now() < retryAfter) return json({error: 'provider_unavailable'}, 502);
    try {
      const data = await (inflight ??= refresh(key).finally(() => { inflight = null; }));
      return json(data, 200, 'public, max-age=300');
    } catch (error) {
      retryAfter = Date.now() + 60_000;
      const code = typeof error?.upstreamCode === 'string' && /^[a-z0-9_]{1,64}$/u.test(error.upstreamCode)
        ? error.upstreamCode : null;
      const requestId = typeof error?.requestId === 'string' && /^[a-zA-Z0-9_-]{1,100}$/u.test(error.requestId)
        ? error.requestId : null;
      const status = Number.isInteger(error?.upstreamStatus) ? error.upstreamStatus : null;
      const reason = ['network_error', 'upstream_unavailable', 'upstream_format', 'invalid_directions'].includes(error?.message)
        ? error.message : 'internal_error';
      const path = ['/listings', '/cities/riyadh/directions'].includes(error?.upstreamPath)
        ? error.upstreamPath : null;
      const networkType = ['Error', 'TypeError', 'AbortError', 'TimeoutError'].includes(error?.networkType)
        ? error.networkType : null;
      const networkCode = ['ECONNREFUSED', 'ECONNRESET', 'ENOTFOUND', 'ETIMEDOUT', 'UND_ERR_CONNECT_TIMEOUT', 'UND_ERR_HEADERS_TIMEOUT', 'ERR_TLS_CERT_ALTNAME_INVALID'].includes(error?.networkCode)
        ? error.networkCode : null;
      console.error(JSON.stringify({event: 'provider_unavailable', reason, path, status, code, request_id: requestId, network_type: networkType, network_code: networkCode}));
      return json({error: 'provider_unavailable', reason, path, upstream_status: status, upstream_code: code, request_id: requestId, network_type: networkType, network_code: networkCode}, 502);
    }
  },
};
