package com.algouda.algouda_real_estate;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

final class WhatsAppInbox extends SQLiteOpenHelper {
    static final ExecutorService WORKER = Executors.newSingleThreadExecutor();

    static long enabledSince(Context context) {
        return context.getSharedPreferences("whatsapp_capture", Context.MODE_PRIVATE)
                .getLong("enabled_since", 0);
    }

    static void setEnabled(Context context, boolean enabled) {
        long since = enabledSince(context);
        context.getSharedPreferences("whatsapp_capture", Context.MODE_PRIVATE).edit()
                .putLong("enabled_since", enabled ? since > 0 ? since : System.currentTimeMillis() : 0)
                .apply();
    }

    WhatsAppInbox(Context context) {
        super(context.getApplicationContext(), "whatsapp_capture.db", null, 1);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE inbound (position INTEGER PRIMARY KEY, id TEXT UNIQUE NOT NULL, "
                + "body TEXT NOT NULL, sender TEXT NOT NULL, source TEXT NOT NULL, "
                + "group_key TEXT NOT NULL, happened INTEGER NOT NULL, consumed INTEGER)");
        db.execSQL("CREATE INDEX inbound_pending ON inbound(consumed, position)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        throw new IllegalStateException("Unsupported inbox schema " + newVersion);
    }

    int add(List<ContentValues> messages, long enabledSince) {
        SQLiteDatabase db = getWritableDatabase();
        int added = 0;
        db.beginTransaction();
        try {
            for (ContentValues values : messages) {
                if (values.getAsLong("happened") < enabledSince) continue;
                if (db.insertWithOnConflict("inbound", null, values, SQLiteDatabase.CONFLICT_IGNORE) != -1) {
                    added++;
                }
            }
            db.delete("inbound", "consumed < ?",
                    new String[]{Long.toString(System.currentTimeMillis() - TimeUnit.DAYS.toMillis(7))});
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return added;
    }

    List<Map<String, Object>> pending() {
        List<Map<String, Object>> result = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query("inbound",
                new String[]{"id", "body", "sender", "source", "group_key", "happened"},
                "consumed IS NULL", null, null, null, "position ASC", "100")) {
            while (cursor.moveToNext()) {
                Map<String, Object> message = new HashMap<>();
                message.put("externalId", cursor.getString(0));
                message.put("body", cursor.getString(1));
                message.put("sender", cursor.getString(2));
                message.put("source", cursor.getString(3));
                message.put("groupId", cursor.getString(4));
                message.put("timestamp", cursor.getLong(5));
                result.add(message);
            }
        }
        return result;
    }

    void acknowledge(List<String> ids) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put("consumed", System.currentTimeMillis());
            values.put("body", "");
            values.put("sender", "");
            values.put("source", "");
            values.put("group_key", "");
            for (String id : ids) {
                db.update("inbound", values, "id = ? AND consumed IS NULL", new String[]{id});
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }
}
