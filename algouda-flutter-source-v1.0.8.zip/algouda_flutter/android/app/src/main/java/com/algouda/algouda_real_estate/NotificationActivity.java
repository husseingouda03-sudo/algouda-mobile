package com.algouda.algouda_real_estate;

import android.Manifest;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

public final class NotificationActivity extends FlutterActivity {
    private static final int ALERT_PERMISSION = 401;
    private MethodChannel channel;

    @Override public void configureFlutterEngine(FlutterEngine engine) {
        super.configureFlutterEngine(engine);
        channel = new MethodChannel(engine.getDartExecutor().getBinaryMessenger(), "algouda/whatsapp_notifications");
        channel.setMethodCallHandler((call, result) -> {
            switch (call.method) {
                case "status":
                    Map<String, Boolean> status = new HashMap<>();
                    status.put("supported", Build.VERSION.SDK_INT >= 24);
                    status.put("enabled", WhatsAppInbox.enabledSince(this) > 0);
                    status.put("access", listenerAllowed());
                    status.put("alerts", WhatsAppNotifications.alertAllowed(this));
                    result.success(status);
                    break;
                case "enable":
                    WhatsAppInbox.setEnabled(this, Boolean.TRUE.equals(call.arguments));
                    result.success(null);
                    break;
                case "listenerSettings":
                    startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                    result.success(null);
                    break;
                case "allowAlerts":
                    if (Build.VERSION.SDK_INT >= 33 &&
                            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
                            !getPreferences(Context.MODE_PRIVATE).getBoolean("asked_alert_permission", false)) {
                        getPreferences(Context.MODE_PRIVATE).edit().putBoolean("asked_alert_permission", true).apply();
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, ALERT_PERMISSION);
                    } else if (!WhatsAppNotifications.alertAllowed(this)) {
                        Intent settings = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                        startActivity(settings);
                    }
                    result.success(null);
                    break;
                case "pending":
                    readInbox(null, result);
                    break;
                case "ack":
                    List<String> ids = call.arguments();
                    readInbox(ids == null ? Collections.emptyList() : ids, result);
                    break;
                default:
                    result.notImplemented();
            }
        });
    }

    @Override public void cleanUpFlutterEngine(FlutterEngine engine) {
        if (channel != null) channel.setMethodCallHandler(null);
        super.cleanUpFlutterEngine(engine);
    }

    private void readInbox(List<String> acknowledged, MethodChannel.Result result) {
        WhatsAppInbox.WORKER.execute(() -> {
            try (WhatsAppInbox inbox = new WhatsAppInbox(this)) {
                Object value = null;
                if (acknowledged == null) value = inbox.pending();
                else inbox.acknowledge(acknowledged);
                Object response = value;
                runOnUiThread(() -> result.success(response));
            } catch (RuntimeException error) {
                runOnUiThread(() -> result.error("inbox", "Unable to read local inbox", null));
            }
        });
    }

    private boolean listenerAllowed() {
        ComponentName component = new ComponentName(this, WhatsAppNotifications.class);
        if (Build.VERSION.SDK_INT >= 27) {
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            return manager.isNotificationListenerAccessGranted(component);
        }
        String enabled = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        if (enabled == null) return false;
        for (String entry : enabled.split(":")) {
            if (component.equals(ComponentName.unflattenFromString(entry))) return true;
        }
        return false;
    }
}
