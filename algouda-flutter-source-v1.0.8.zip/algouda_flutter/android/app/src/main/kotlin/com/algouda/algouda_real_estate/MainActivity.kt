package com.algouda.algouda_real_estate

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
