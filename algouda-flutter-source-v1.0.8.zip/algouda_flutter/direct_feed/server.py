"""Read-only Riyadh direct-listing feed for the mobile app."""
import json
import os
import re
import threading
import time
import unicodedata
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlencode, urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

KITE_URL = "https://api.kite.sa/v1"
PLATFORMS = {"aqar": "عقار", "haraj": "حراج", "deal": "ديل", "bayut": "بيوت"}
TYPES = {"villa": "فيلا", "duplex": "فيلا", "apartment": "شقة",
         "floor": "دور", "land": "أرض", "warehouse": "مستودع"}
ZONES = {f"{side} الرياض" for side in ("شمال", "شرق", "غرب", "جنوب")}
DEALS = {"sale": "بيع", "rent": "إيجار"}
EXPLICIT_OWNER = re.compile(
    r"(?<!\w)(?:انا المالك|انا مالك (?:العقار|هذا العقار)|البيع من المالك مباشرة|"
    r"التاجير من المالك مباشرة|من المالك مباشرة|من المالك مباشره)(?!\w)"
)
INTERMEDIARY = re.compile(
    r"(?<!\w)(?:وسيط عقاري|مسوق عقاري|مكتب عقاري|مكتب\s+\S+\s+للعقارات|"
    r"شركة عقارية|مؤسسة عقارية|مباشر مع المالك|مباشر مع الوكيل|انا الوكيل|"
    r"اعلان نيابة عن)(?!\w)"
)
BUSINESS = re.compile(r"(?<!\w)(?:شركة|مكتب|مؤسسة)(?!\w)")


def normalized(value):
    value = str(value or "").translate(str.maketrans("أإآ", "ااا"))
    return "".join(c for c in value if not unicodedata.combining(c))


def owner_listing(row):
    advertiser = row.get("advertiser") or {}
    role = (advertiser.get("type") or "").lower()
    if (advertiser.get("company") or advertiser.get("cr")
            or advertiser.get("fal_number")
            or BUSINESS.search(normalized(advertiser.get("name")))):
        return False
    copy = normalized(f"{row.get('title') or ''} {row.get('description') or ''}")
    if INTERMEDIARY.search(copy):
        return False
    if role in ("individual_owner", "owner"):
        return True
    return not role and bool(EXPLICIT_OWNER.search(copy))


def offer(row, zones):
    if not owner_listing(row):
        return None
    source = PLATFORMS.get((row.get("source") or {}).get("name"))
    location = row.get("location") or {}
    city = location.get("city")
    district = location.get("neighborhood_name_ar")
    zone = zones.get(location.get("neighborhood_id"))
    deal = DEALS.get(row.get("listing_type"))
    kind = TYPES.get(row.get("property_type"))
    url = row.get("url") or ""
    parsed = urlsplit(url)
    if (not source or city != "riyadh" or not district or not zone or not deal or not kind
            or parsed.scheme != "https" or parsed.netloc not in ("kite.sa", "www.kite.sa")
            or parsed.query or parsed.fragment
            or not re.fullmatch(r"/(?:(?:ar|en)/)?listing/\d+/?", parsed.path)):
        return None
    copy = normalized(f"{row.get('title') or ''} {row.get('description') or ''}")
    if kind == "أرض" and (row.get("plot") or {}).get("zoning") == "industrial":
        kind = "أرض صناعية"
    if kind in ("أرض", "فيلا") and re.search(r"(?:فيلا|فله|فلة) بقيم[ةه] ارض", copy):
        kind = "فيلا بقيمة أرض"
    if kind in ("أرض صناعية", "مستودع") and zone != "جنوب الرياض":
        return None

    price = (row.get("price") or {}).get("yearly_sar")
    area = row.get("area_sqm")
    information = []
    if isinstance(price, int) and price > 0:
        information.append(f"{price:,} ريال" + (" سنويًا" if deal == "إيجار" else ""))
    if isinstance(area, (int, float)) and area > 0:
        information.append(f"{area:g} م²")
    return {
        "title": f"{kind} · {district}"[:160], "district": district[:100],
        "zone": zone, "type": kind, "deal": deal, "role": "المالك بحسب الإعلان",
        "platform": source, "url": url, "notes": " · ".join(information),
    }


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def kite_request(api_key, path, params):
    query = f"?{urlencode(params)}" if params else ""
    request = Request(KITE_URL + path + query, headers={
        "Authorization": f"Bearer {api_key}", "Accept": "application/json",
    })
    with build_opener(NoRedirect()).open(request, timeout=12) as response:
        return json.load(response)


class Feed:
    def __init__(self, key, request=kite_request, ttl=1800, pages=2):
        self.key, self.request, self.ttl, self.pages = key, request, ttl, pages
        self.lock = threading.Lock()
        self.zones = {}
        self.zones_since = 0
        self.snapshot = None
        self.valid_until = 0

    def listings(self, mode):
        cursor = None
        for _ in range(self.pages):
            params = {
                "city": "riyadh", "listing_type": mode, "sort": "newest",
                "source": ",".join(PLATFORMS), "property_type": ",".join(TYPES),
                "limit": 25,
            }
            if cursor:
                params["cursor"] = cursor
            page = self.request(self.key, "/listings", params)
            yield from page["data"]
            next_cursor = page["pagination"].get("next_cursor")
            if not next_cursor or next_cursor == cursor:
                return
            cursor = next_cursor

    def read(self):
        with self.lock:
            now = time.monotonic()
            if self.snapshot is not None and now < self.valid_until:
                return self.snapshot
            if not self.zones or now - self.zones_since >= 86400:
                result = self.request(self.key, "/cities/riyadh/directions", {})
                self.zones = {
                    neighborhood: direction["name_ar"]
                    for direction in result["data"] if direction.get("name_ar") in ZONES
                    for neighborhood in direction["neighborhood_ids"]
                }
                if not self.zones:
                    raise ValueError("No Riyadh directions returned")
                self.zones_since = now
            offers = {}
            for mode in DEALS:
                for row in self.listings(mode):
                    result = offer(row, self.zones)
                    if result is not None:
                        offers.setdefault(result["url"], result)
            self.snapshot = {"version": 1, "offers": list(offers.values())[:400]}
            self.valid_until = time.monotonic() + self.ttl
            return self.snapshot


def main():
    key = os.environ.get("KITE_API_KEY")
    if not key:
        raise SystemExit("Configure KITE_API_KEY in the server environment.")
    feed = Feed(key)

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path == "/health":
                return self.respond(200, {"ok": True})
            if self.path != "/offers":
                return self.respond(404, {"error": "not_found"})
            try:
                payload = feed.read()
            except (OSError, ValueError, TypeError, KeyError):
                return self.respond(502, {"error": "source_unavailable"})
            self.respond(200, payload)

        def respond(self, status, payload):
            result = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(result)))
            self.send_header("Cache-Control", "no-store" if status != 200 else "max-age=600")
            self.end_headers()
            self.wfile.write(result)

    ThreadingHTTPServer(("0.0.0.0", int(os.environ.get("PORT", "8080"))), Handler).serve_forever()


if __name__ == "__main__":
    main()
