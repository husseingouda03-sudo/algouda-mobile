import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as path;
import 'package:sqflite/sqflite.dart';
import 'messages.dart';

class Repository {
  Repository(this.db);
  final Database db;

  static Future<Repository> open() async {
    final file = path.join(await getDatabasesPath(), 'algouda_whatsapp.db');
    final db = await openDatabase(
      file,
      version: 1,
      onCreate: (db, _) async {
        await db.execute(
          'CREATE TABLE messages (position INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT UNIQUE NOT NULL, data TEXT NOT NULL)',
        );
        await db.execute(
          'CREATE TABLE settings (id TEXT PRIMARY KEY, data TEXT NOT NULL)',
        );
      },
    );
    return Repository(db);
  }

  Future<MessageIndex> messages() async {
    final rows = await db.query('messages', orderBy: 'position DESC');
    return rows.isEmpty
        ? const MessageIndex()
        : compute(decodeMessageIndex, rows);
  }

  Future<int> add(
    Iterable<Map<String, dynamic>> input, {
    String? relay,
    int? cursor,
  }) async {
    return db.transaction((tx) async {
      final previous =
          Sqflite.firstIntValue(
            await tx.rawQuery('SELECT count(*) FROM messages'),
          ) ??
          0;
      final batch = tx.batch();
      for (final row in input) {
        if (textOf(row, 'body').trim().isEmpty) continue;
        final original = textOf(row, 'externalId');
        final identity =
            original.isNotEmpty && relay != null
                ? [relay, original]
                : [
                  row['source'],
                  row['sender'],
                  row['date'],
                  textOf(row, 'body').replaceAll(RegExp(r'\s+'), ' ').trim(),
                ];
        final id = sha256.convert(utf8.encode(jsonEncode(identity))).toString();
        batch.insert('messages', {
          'id': id,
          'data': jsonEncode({...row, 'id': id}),
        }, conflictAlgorithm: ConflictAlgorithm.ignore);
      }
      if (relay != null && cursor != null) {
        batch.insert('settings', {
          'id': 'cursor:$relay',
          'data': jsonEncode(cursor),
        }, conflictAlgorithm: ConflictAlgorithm.replace);
      }
      await batch.commit(noResult: true);
      final total =
          Sqflite.firstIntValue(
            await tx.rawQuery('SELECT count(*) FROM messages'),
          ) ??
          0;
      return total - previous;
    });
  }

  Future<void> update(Message row) async => db.update(
    'messages',
    {'data': jsonEncode(row.data)},
    where: 'id = ?',
    whereArgs: [row.id],
  );

  Future<dynamic> setting(String id) async {
    final rows = await db.query(
      'settings',
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    return rows.isEmpty ? null : jsonDecode(rows.first['data'] as String);
  }

  Future<void> save(String id, Object value) async => db.insert('settings', {
    'id': id,
    'data': jsonEncode(value),
  }, conflictAlgorithm: ConflictAlgorithm.replace);

  Future<void> remove(String id) async =>
      db.delete('settings', where: 'id = ?', whereArgs: [id]);
}

class MessageIndex {
  const MessageIndex({
    this.messages = const [],
    this.offers = const [],
    this.fresh = const [],
    this.areas = districts,
    this.offerGroups = const {},
  });

  final List<Message> messages, offers, fresh;
  final List<String> areas;
  final Map<String, String> offerGroups;
}

MessageIndex decodeMessageIndex(List<Map<String, Object?>> rows) {
  final current = <Message>[];
  final older = <Message>[];
  for (final row in rows) {
    final message = Message(
      jsonDecode(row['data'] as String) as Map<String, dynamic>,
    );
    (message.historical ? older : current).add(message);
  }
  older.sort((a, b) => b.date.compareTo(a.date));
  final messages = [...current, ...older];
  final offers = <Message>[];
  final fresh = <Message>[];
  final areas = {...districts};
  final groups = <String, String>{};
  for (final message in messages) {
    if (message.kind == 'offer') {
      offers.add(message);
      areas.add(message.details.place);
      if (message.groupId.isNotEmpty) {
        groups.putIfAbsent(message.groupId, () => message.source);
      }
    } else if (message.kind == 'request' && !message.seen) {
      fresh.add(message);
    }
  }
  return MessageIndex(
    messages: messages,
    offers: offers,
    fresh: fresh,
    areas: areas.toList(),
    offerGroups: groups,
  );
}

class Relay {
  Relay(String url, this.key) : base = Uri.parse(url.trim()) {
    if (base.scheme != 'https' ||
        base.host.isEmpty ||
        base.userInfo.isNotEmpty ||
        base.hasQuery ||
        base.hasFragment ||
        key.trim().isEmpty) {
      throw const FormatException('أدخل عنوان HTTPS ومفتاح قراءة صالحين');
    }
  }
  final Uri base;
  final String key;
  static const dashboardOrigin =
      'https://algouda-whatsapp.confidentchrysanthemum4.chatgpt.site';
  String get url => base.toString().replaceFirst(RegExp(r'/$'), '');
  Map<String, String> get headers => {
    'Authorization': 'Bearer $key',
    'Origin': dashboardOrigin,
    'Content-Type': 'application/json',
  };

  Future<Map<String, dynamic>> request(
    String endpoint, {
    int? after,
    Map<String, dynamic>? body,
  }) async {
    final target = Uri.parse(
      '$url/$endpoint',
    ).replace(queryParameters: after == null ? null : {'after': '$after'});
    final client = http.Client();
    try {
      final request = http.Request(body == null ? 'GET' : 'POST', target)
        ..followRedirects = false;
      request.headers.addAll(headers);
      if (body != null) request.body = jsonEncode(body);
      final response = await client
          .send(request)
          .then(http.Response.fromStream)
          .timeout(const Duration(seconds: 15));
      final decoded = jsonDecode(utf8.decode(response.bodyBytes));
      if (response.statusCode == 409)
        throw const FormatException('فعّل نسخ السجل على خادم الاستقبال');
      if (response.statusCode != 200 || decoded is! Map<String, dynamic>) {
        throw const FormatException(
          'تحقق من رابط خادم الاستقبال ومفتاح القراءة',
        );
      }
      return decoded;
    } on FormatException {
      rethrow;
    } finally {
      client.close();
    }
  }
}
