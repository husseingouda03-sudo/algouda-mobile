import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:url_launcher/url_launcher.dart';
import 'direct_offers.dart';
import 'messages.dart';
import 'repository.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AlgoudaApp());
}

const green = Color(0xff075c44);
const dark = Color(0xff10352f);
const background = Color(0xfff4f8f6);
const brand = 'الجودة العقارية';

class AlgoudaApp extends StatelessWidget {
  const AlgoudaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: brand,
    debugShowCheckedModeBanner: false,
    locale: const Locale('ar'),
    supportedLocales: const [Locale('ar')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: green),
      scaffoldBackgroundColor: background,
      appBarTheme: const AppBarTheme(
        backgroundColor: dark,
        foregroundColor: Colors.white,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(13)),
      ),
      cardTheme: CardThemeData(
        color: Colors.white,
        margin: const EdgeInsets.only(bottom: 10),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: Color(0xffdce7e1)),
        ),
      ),
    ),
    home: const Workspace(),
  );
}

class Workspace extends StatefulWidget {
  const Workspace({super.key});
  @override
  State<Workspace> createState() => _WorkspaceState();
}

class _WorkspaceState extends State<Workspace> with WidgetsBindingObserver {
  static const notificationChannel = MethodChannel(
    'algouda/whatsapp_notifications',
  );
  Repository? repository;
  MessageIndex messageIndex = const MessageIndex();
  (MessageIndex, int, String, String, String, String, String)? filterKey;
  List<Message> filtered = const [];
  Relay? relay;
  Timer? timer, notificationTimer;
  int section = 0, limit = 60, reloadGeneration = 0;
  String query = '', area = '', intent = '', messageKind = '', offerGroup = '';
  String failure = '';
  bool connected = false,
      syncing = false,
      importing = false,
      historyBusy = false;
  Map<String, dynamic> history = {}, features = {};
  bool readingNotifications = false;

  List<Message> get messages => messageIndex.messages;
  List<Message> get offers => messageIndex.offers;
  List<Message> get fresh => messageIndex.fresh;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) unawaited(setup());
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    timer?.cancel();
    notificationTimer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      unawaited(startNotificationSync());
    } else {
      notificationTimer?.cancel();
      notificationTimer = null;
    }
  }

  Future<void> setup() async {
    try {
      const timeout = Duration(seconds: 8);
      final store = await Repository.open().timeout(timeout);
      final saved = await store.messages().timeout(timeout);
      if (!mounted) return;
      setState(() {
        repository = store;
        messageIndex = saved;
      });
      unawaited(startNotificationSync());
    } catch (_) {
      if (mounted) {
        setState(() => failure = 'تعذر فتح مخزن الرسائل على الجهاز.');
      }
      return;
    }
    // Local messages can already be used while the saved relay is read.
    try {
      final options = await repository!
          .setting('relay')
          .timeout(const Duration(seconds: 8));
      if (!mounted) return;
      if (options is Map &&
          options['url'] is String &&
          options['key'] is String) {
        relay ??= Relay(options['url'] as String, options['key'] as String);
      }
    } catch (_) {
      // An unavailable relay setting should not prevent offline use.
    }
    if (!mounted) return;
    timer = Timer.periodic(
      const Duration(seconds: 15),
      (_) => unawaited(sync()),
    );
    unawaited(sync());
  }

  Future<void> reload() async {
    final generation = ++reloadGeneration;
    final rows = await repository!.messages();
    if (mounted && generation == reloadGeneration) {
      setState(() => messageIndex = rows);
    }
  }

  bool get supportsAndroidSettings =>
      !kIsWeb && defaultTargetPlatform == TargetPlatform.android;

  Future<Map<String, bool>> notificationStatus() async {
    if (!supportsAndroidSettings) return const {};
    try {
      return await notificationChannel.invokeMapMethod<String, bool>(
            'status',
          ) ??
          const {};
    } on PlatformException {
      return const {};
    } on MissingPluginException {
      return const {};
    }
  }

  Future<void> startNotificationSync() async {
    if (!mounted || repository == null) return;
    final status = await notificationStatus();
    if (!mounted) return;
    notificationTimer?.cancel();
    notificationTimer = null;
    if (status['enabled'] != true ||
        status['access'] != true ||
        WidgetsBinding.instance.lifecycleState != AppLifecycleState.resumed) {
      return;
    }
    notificationTimer = Timer.periodic(
      const Duration(seconds: 4),
      (_) => unawaited(syncNotifications()),
    );
    unawaited(syncNotifications());
  }

  Future<void> syncNotifications() async {
    final store = repository;
    if (readingNotifications || store == null) return;
    readingNotifications = true;
    var inserted = 0;
    try {
      for (var page = 0; page < 5 && mounted; page++) {
        final pending = await notificationChannel.invokeListMethod<Map>(
          'pending',
        );
        if (pending == null || pending.isEmpty) break;
        final rows =
            pending.map((row) {
              final timestamp = (row['timestamp'] as num).toInt();
              return {
                ...Map<String, dynamic>.from(row),
                'date':
                    DateTime.fromMillisecondsSinceEpoch(
                      timestamp,
                    ).toIso8601String(),
              };
            }).toList();
        inserted += await store.add(rows, relay: 'android-whatsapp-inbox');
        await notificationChannel.invokeMethod<void>(
          'ack',
          rows.map((row) => row['externalId'] as String).toList(),
        );
        if (pending.length < 100) break;
      }
    } on PlatformException {
      // The Android inbox retains the batch for the next retry.
    } finally {
      try {
        if (inserted > 0 && mounted) await reload();
      } finally {
        readingNotifications = false;
      }
    }
  }

  Future<void> openNotificationSettings() async {
    final status = await notificationStatus();
    if (!mounted) return;
    final enabled = status['enabled'] == true;
    final access = status['access'] == true;
    final alerts = status['alerts'] == true;
    if (status['supported'] != true) {
      notice('التقاط الإشعارات متاح على أندرويد ٧ فأحدث.');
      return;
    }
    final action = await showDialog<String>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('تنبيهات العقار وواتساب'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'بعد إذنك، يلتقط التطبيق إشعارات واتساب، وحراج، وعقار، وبيوت، ووصلت، وديل إذا كانت تطبيقاتها ترسل تنبيهات على الهاتف. يحفظ النص محليًا على الجهاز للفرز، ولا يقرأ محادثات المنصات. الإذن اختياري ويمكن إيقافه من هنا.',
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'التقاط التنبيهات: ${enabled && access ? 'شغّال' : 'متوقف'}',
                  ),
                  Text(
                    'إشعارات الجودة العقارية: ${alerts ? 'مسموح بها' : 'مقفولة'}',
                  ),
                ],
              ),
            ),
            actions: [
              if (!enabled || !access)
                FilledButton(
                  onPressed: () => Navigator.pop(context, 'enable'),
                  child: const Text('تشغيل التقاط التنبيهات'),
                ),
              if (!alerts)
                TextButton(
                  onPressed: () => Navigator.pop(context, 'alerts'),
                  child: const Text('السماح بالتنبيهات'),
                ),
              if (enabled)
                TextButton(
                  onPressed: () => Navigator.pop(context, 'disable'),
                  child: const Text('إيقاف الالتقاط'),
                ),
            ],
          ),
    );
    if (!mounted || action == null) return;
    try {
      if (action == 'alerts') {
        await notificationChannel.invokeMethod<void>('allowAlerts');
      } else {
        await notificationChannel.invokeMethod<void>(
          'enable',
          action == 'enable',
        );
        if (action == 'enable' && !access) {
          await notificationChannel.invokeMethod<void>('listenerSettings');
        } else {
          unawaited(startNotificationSync());
        }
      }
    } on PlatformException {
      notice('تعذر فتح إعدادات الإشعارات.');
    }
  }

  void notice(String message) {
    if (mounted)
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> pull(Relay target) async {
    final store = repository!;
    var cursor = (await store.setting('cursor:${target.url}')) as int? ?? 0;
    var count = 0;
    try {
      for (var page = 0; page < 8; page++) {
        final data = await target.request('messages', after: cursor);
        if (data['messages'] is! List)
          throw const FormatException('تنسيق الرسائل غير متوافق');
        features =
            data['features'] is Map
                ? Map<String, dynamic>.from(data['features'] as Map)
                : {};
        history =
            data['history'] is Map
                ? Map<String, dynamic>.from(data['history'] as Map)
                : {};
        if (features['auto'] == true) {
          await target.request(
            'inventory',
            body: {'enabled': false, 'inventory': []},
          );
        }
        final next = data['cursor'];
        final rows = (data['messages'] as List)
            .whereType<Map>()
            .map((row) => Map<String, dynamic>.from(row))
            .where((row) => textOf(row, 'externalId').isNotEmpty);
        count += await store.add(
          rows,
          relay: target.url,
          cursor: next is int && next >= cursor ? next : cursor,
        );
        if (data['more'] != true || next is! int || next <= cursor) break;
        cursor = next;
      }
    } finally {
      if (count > 0) await reload();
    }
  }

  Future<void> sync() async {
    final target = relay;
    if (target == null ||
        syncing ||
        historyBusy ||
        repository == null ||
        !mounted)
      return;
    setState(() => syncing = true);
    try {
      await pull(target);
      connected = true;
    } catch (_) {
      connected = false;
    } finally {
      if (mounted) setState(() => syncing = false);
    }
  }

  String historyStatus() => switch (history['state']) {
    'requested' => 'تم طلب النسخة من Meta. بانتظار الرسائل.',
    'receiving' =>
      'جاري استقبال السجل. وصل للخادم ${history['count'] ?? 0} رسالة.',
    'complete' =>
      'استلم الخادم السجل المتاح. عدد الرسائل ${history['count'] ?? 0}.',
    'declined' => 'مشاركة السجل لم تُفعّل في واتساب بزنس.',
    'failed' =>
      history['code'] == 2593108
          ? 'انتهت مهلة طلب السجل من Meta.'
          : 'تعذر طلب السجل من Meta.',
    _ =>
      features['historySync'] == true
          ? 'السجل متاح للطلب بعد موافقتك في واتساب بزنس.'
          : 'نسخ السجل يحتاج تفعيل Coexistence وإعداد خادم الاستقبال.',
  };

  Future<void> copyHistory() async {
    if (relay == null || historyBusy || syncing) return;
    setState(() => historyBusy = true);
    try {
      history = await relay!.request('history-sync', body: {});
      notice(historyStatus());
    } catch (_) {
      notice('تعذر طلب السجل. راجع إعداد خادم الاستقبال.');
    } finally {
      if (mounted) setState(() => historyBusy = false);
    }
  }

  Future<void> connect() async {
    if (repository == null || syncing || historyBusy) return;
    final address = TextEditingController(text: relay?.url ?? '');
    final key = TextEditingController(text: relay?.key ?? '');
    final action = await showDialog<String>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('ربط واتساب بزنس'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'اتصل بخادم الاستقبال المرتبط برقمك على منصة Meta.',
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: address,
                    keyboardType: TextInputType.url,
                    decoration: const InputDecoration(
                      labelText: 'رابط خادم الاستقبال',
                      hintText: 'https://',
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: key,
                    obscureText: true,
                    autocorrect: false,
                    enableSuggestions: false,
                    decoration: const InputDecoration(
                      labelText: 'مفتاح القراءة',
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(historyStatus()),
                  if (connected &&
                      features['historySync'] == true &&
                      const ['idle', 'failed'].contains(history['state']))
                    TextButton.icon(
                      onPressed: () => Navigator.pop(context, 'history'),
                      icon: const Icon(Icons.history),
                      label: const Text('نسخ سجل واتساب بزنس'),
                    ),
                ],
              ),
            ),
            actions: [
              if (relay != null)
                TextButton(
                  onPressed: () => Navigator.pop(context, 'disconnect'),
                  child: const Text('قطع الاتصال'),
                ),
              FilledButton(
                onPressed: () => Navigator.pop(context, 'connect'),
                child: const Text('اختبار الاتصال وحفظه'),
              ),
            ],
          ),
    );
    final url = address.text, token = key.text.trim();
    address.dispose();
    key.dispose();
    if (!mounted) return;
    if (action == 'history') {
      await copyHistory();
      return;
    }
    if (action == 'disconnect') {
      await repository!.remove('relay');
      if (mounted)
        setState(() {
          relay = null;
          connected = false;
          history = {};
          features = {};
        });
      return;
    }
    if (action != 'connect' || syncing) return;
    setState(() => syncing = true);
    final previousHistory = history, previousFeatures = features;
    try {
      final target = Relay(url, token);
      await pull(target);
      await repository!.save('relay', {'url': target.url, 'key': token});
      relay = target;
      connected = true;
      notice('تم ربط خادم الاستقبال ومزامنة الرسائل');
    } catch (error) {
      history = previousHistory;
      features = previousFeatures;
      notice(
        error is FormatException
            ? error.message
            : 'تعذر الاتصال بخادم الاستقبال',
      );
    } finally {
      if (mounted) setState(() => syncing = false);
    }
  }

  Future<void> importFiles() async {
    if (repository == null || importing) return;
    setState(() => importing = true);
    try {
      final result = await FilePicker.platform.pickFiles(
        allowMultiple: true,
        type: FileType.custom,
        allowedExtensions: ['txt'],
        withData: false,
      );
      if (result == null) return;
      final files = <Map<String, dynamic>>[];
      for (final file in result.files) {
        if (file.size > 8 * 1024 * 1024) {
          notice('الحد الأقصى ٨ ميجابايت لكل ملف.');
          return;
        }
        final path = file.path;
        if (path == null) {
          notice('تعذر فتح أحد الملفات.');
          return;
        }
        final name = file.name
            .replaceFirst(RegExp(r'\.txt$', caseSensitive: false), '')
            .replaceFirst(
              RegExp(r'^WhatsApp Chat with\s+', caseSensitive: false),
              '',
            );
        files.addAll(await compute(_parseExportFile, (path, name)));
      }
      final count = await repository!.add(files);
      await reload();
      notice(
        count > 0 ? 'تم استيراد $count رسالة' : 'مفيش رسائل جديدة للاستيراد',
      );
    } catch (_) {
      notice('تعذر استيراد الملفات');
    } finally {
      if (mounted) setState(() => importing = false);
    }
  }

  Future<void> paste() async {
    if (repository == null) return;
    final body = TextEditingController(), sender = TextEditingController();
    final submit = await showDialog<bool>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('لصق رسالة واتساب'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: sender,
                  decoration: const InputDecoration(labelText: 'اسم المرسل'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: body,
                  maxLines: 5,
                  decoration: const InputDecoration(labelText: 'نص الرسالة'),
                ),
              ],
            ),
            actions: [
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('استيراد وفرز'),
              ),
            ],
          ),
    );
    final rows = parseExport(body.text, 'نص ملصوق', sender: sender.text.trim());
    body.dispose();
    sender.dispose();
    if (submit != true || rows.isEmpty) return;
    try {
      final count = await repository!.add(rows);
      await reload();
      notice(count > 0 ? 'تم استيراد الرسالة' : 'الرسالة موجودة بالفعل');
    } catch (_) {
      notice('تعذر حفظ الرسالة');
    }
  }

  Future<void> showMessage(Message item) async {
    if (!item.seen) {
      await repository!.update(item.update({'seen': true}));
      await reload();
    }
    if (!mounted) return;
    final matches =
        item.kind == 'request'
            ? suggestions(offers, item.details).take(8).toList()
            : <Message>[];
    final action = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => _MessageSheet(item: item, matches: matches),
    );
    if (action == null || !mounted) return;
    if (action == 'dismiss' || action == 'restore') {
      await repository!.update(
        item.update({'seen': true, 'dismissed': action == 'dismiss'}),
      );
      await reload();
      if (action == 'dismiss') notice('تم حفظ اختيار «لا ترسل»');
      if (action == 'restore')
        await showMessage(item.update({'dismissed': false, 'seen': true}));
      return;
    }
    await showDialog<void>(
      context: context,
      builder: (context) => _ReplyDialog(item: item, text: action),
    );
  }

  Future<void> smartSearch() async {
    final controller = TextEditingController(text: query);
    final text = await showDialog<String>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('البحث الذكي'),
            content: TextField(
              controller: controller,
              maxLines: 3,
              decoration: const InputDecoration(
                hintText: 'عايز فيلا في الرمال بحدود ٢ مليون ريال',
              ),
            ),
            actions: [
              FilledButton(
                onPressed: () => Navigator.pop(context, controller.text.trim()),
                child: const Text('ابحث'),
              ),
            ],
          ),
    );
    controller.dispose();
    if (text == null || text.isEmpty || !mounted) return;
    Map<String, dynamic> hints = {};
    final target = relay;
    if (features['ai'] == true && target != null) {
      try {
        final data = await target.request('interpret', body: {'body': text});
        if (data['analysis'] is Map)
          hints = Map<String, dynamic>.from(data['analysis'] as Map);
      } catch (_) {
        /* Search still works locally. */
      }
    }
    if (!mounted) return;
    final parsed = criteria(text, hints);
    final matches =
        parsed.useful
            ? suggestions(offers, parsed).take(30).toList()
            : <Message>[];
    final selected = await showModalBottomSheet<Message>(
      context: context,
      showDragHandle: true,
      builder:
          (context) => SafeArea(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text(
                  'العروض الأقرب للطلب',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                if (matches.isEmpty)
                  const Padding(
                    padding: EdgeInsets.only(top: 16),
                    child: Text('مفيش عروض توافق بيانات البحث.'),
                  ),
                for (final item in matches)
                  ListTile(
                    title: Text(item.title),
                    subtitle: Text(item.details.summary),
                    onTap: () => Navigator.pop(context, item),
                  ),
              ],
            ),
          ),
    );
    if (selected != null && mounted) await showMessage(selected);
  }

  Widget offerFilter(String value, String label) => ChoiceChip(
    label: Text(label),
    selected: intent == value,
    onSelected:
        (_) => setState(() {
          intent = value;
          limit = 60;
        }),
  );

  List<Message> visibleMessages() {
    final key = (
      messageIndex,
      section,
      query,
      area,
      intent,
      messageKind,
      offerGroup,
    );
    if (filterKey == key) return filtered;
    final String needle = normalize(query.trim());
    final source = switch (section) {
      0 => offers,
      2 => fresh,
      _ => messages,
    };
    filtered =
        source
            .where(
              (item) =>
                  (section != 0 ||
                      ((area.isEmpty || item.details.place == area) &&
                          (intent.isEmpty || item.details.intent == intent) &&
                          (offerGroup.isEmpty ||
                              item.groupId == offerGroup))) &&
                  (section != 1 ||
                      messageKind.isEmpty ||
                      item.kind == messageKind) &&
                  (needle.isEmpty || item.searchableText.contains(needle)),
            )
            .toList();
    filterKey = key;
    return filtered;
  }

  @override
  Widget build(BuildContext context) {
    final rows = visibleMessages();
    final tabs = ['العروض', 'المحادثات', 'التنبيهات'];
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text(brand),
        actions: [
          if (supportsAndroidSettings)
            IconButton(
              tooltip: 'إعداد تنبيهات واتساب',
              onPressed: openNotificationSettings,
              icon: const Icon(Icons.notification_add_outlined),
            ),
          IconButton(
            tooltip: 'ربط واتساب بزنس',
            onPressed: connect,
            icon: Icon(connected ? Icons.cloud_done_outlined : Icons.link),
          ),
          IconButton(
            tooltip: 'عروض مباشرة',
            icon: const Icon(Icons.real_estate_agent_outlined),
            onPressed:
                repository == null
                    ? null
                    : () {
                      Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder:
                              (_) => DirectOffersPage(repository: repository!),
                        ),
                      );
                    },
          ),
          PopupMenuButton<String>(
            tooltip: 'استيراد رسائل',
            onSelected: (action) => action == 'file' ? importFiles() : paste(),
            itemBuilder:
                (context) => const [
                  PopupMenuItem(
                    value: 'file',
                    child: Text('استيراد ملفات واتساب'),
                  ),
                  PopupMenuItem(value: 'paste', child: Text('لصق رسالة')),
                ],
          ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: section,
        onDestinationSelected:
            (value) => setState(() {
              section = value;
              limit = 60;
            }),
        destinations: [
          const NavigationDestination(
            icon: Icon(Icons.apartment_outlined),
            selectedIcon: Icon(Icons.apartment),
            label: 'العروض',
          ),
          const NavigationDestination(
            icon: Icon(Icons.chat_bubble_outline),
            label: 'المحادثات',
          ),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: fresh.isNotEmpty,
              label: Text('${fresh.length}'),
              child: const Icon(Icons.notifications_none),
            ),
            label: 'التنبيهات',
          ),
        ],
      ),
      body:
          failure.isNotEmpty
              ? Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(failure),
                    TextButton(
                      onPressed: () {
                        setState(() => failure = '');
                        unawaited(setup());
                      },
                      child: const Text('حاول مرة تانية'),
                    ),
                  ],
                ),
              )
              : repository == null
              ? const Center(child: CircularProgressIndicator())
              : SafeArea(
                child: RefreshIndicator(
                  onRefresh: () async {
                    if (notificationTimer != null) await syncNotifications();
                    await sync();
                  },
                  child: ListView.builder(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 20),
                    itemCount:
                        1 +
                        (rows.isEmpty ? 1 : rows.length.clamp(0, limit)) +
                        (rows.length > limit ? 1 : 0),
                    itemBuilder: (context, index) {
                      if (index == 0)
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(17),
                              decoration: BoxDecoration(
                                color: const Color(0xffe2f1e8),
                                borderRadius: BorderRadius.circular(17),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    tabs[section],
                                    style: theme.textTheme.headlineSmall
                                        ?.copyWith(fontWeight: FontWeight.bold),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(switch (section) {
                                    0 => '${offers.length} عرض محفوظ',
                                    1 => '${messages.length} رسالة محفوظة',
                                    _ => '${fresh.length} طلب جديد',
                                  }),
                                  const SizedBox(height: 10),
                                  Wrap(
                                    spacing: 8,
                                    runSpacing: 4,
                                    children: [
                                      FilledButton.icon(
                                        onPressed:
                                            importing ? null : importFiles,
                                        icon: const Icon(
                                          Icons.file_upload_outlined,
                                        ),
                                        label: const Text('استيراد رسائل'),
                                      ),
                                      if (section == 0)
                                        OutlinedButton.icon(
                                          onPressed: smartSearch,
                                          icon: const Icon(Icons.manage_search),
                                          label: const Text('بحث ذكي'),
                                        ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            if (syncing)
                              const Padding(
                                padding: EdgeInsets.only(top: 6),
                                child: LinearProgressIndicator(),
                              ),
                            const SizedBox(height: 12),
                            TextField(
                              onChanged:
                                  (value) => setState(() {
                                    query = value;
                                    limit = 60;
                                  }),
                              decoration: const InputDecoration(
                                prefixIcon: Icon(Icons.search),
                                hintText: 'ابحث بالحي أو المرسل أو نص الرسالة',
                              ),
                            ),
                            if (section == 0) ...[
                              if (messageIndex.offerGroups.isNotEmpty) ...[
                                const SizedBox(height: 10),
                                DropdownButtonFormField<String>(
                                  value: offerGroup,
                                  isExpanded: true,
                                  decoration: const InputDecoration(
                                    labelText: 'جروب الإعلان',
                                  ),
                                  items: [
                                    const DropdownMenuItem(
                                      value: '',
                                      child: Text('كل الجروبات والمحادثات'),
                                    ),
                                    for (final group
                                        in messageIndex.offerGroups.entries)
                                      DropdownMenuItem(
                                        value: group.key,
                                        child: Text(
                                          group.value,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                  ],
                                  onChanged:
                                      (group) => setState(() {
                                        offerGroup = group ?? '';
                                        limit = 60;
                                      }),
                                ),
                              ],
                              const SizedBox(height: 8),
                              Wrap(
                                spacing: 8,
                                children: [
                                  offerFilter('', 'الكل'),
                                  offerFilter('بيع', 'بيع'),
                                  offerFilter('إيجار', 'إيجار'),
                                ],
                              ),
                              const SizedBox(height: 8),
                              DropdownButtonFormField<String>(
                                value: area,
                                isExpanded: true,
                                decoration: const InputDecoration(
                                  labelText: 'الحي',
                                ),
                                items: [
                                  const DropdownMenuItem(
                                    value: '',
                                    child: Text('كل الأحياء'),
                                  ),
                                  for (final value in messageIndex.areas)
                                    DropdownMenuItem(
                                      value: value,
                                      child: Text(value),
                                    ),
                                ],
                                onChanged:
                                    (value) => setState(() {
                                      area = value ?? '';
                                      limit = 60;
                                    }),
                              ),
                            ],
                            if (section == 1) ...[
                              const SizedBox(height: 8),
                              Wrap(
                                spacing: 8,
                                children: [
                                  for (final pair in const [
                                    ('', 'الكل'),
                                    ('request', 'الطلبات'),
                                    ('offer', 'العروض'),
                                    ('other', 'باقي الرسائل'),
                                  ])
                                    ChoiceChip(
                                      label: Text(pair.$2),
                                      selected: messageKind == pair.$1,
                                      onSelected:
                                          (_) => setState(() {
                                            messageKind = pair.$1;
                                            limit = 60;
                                          }),
                                    ),
                                ],
                              ),
                            ],
                            const SizedBox(height: 14),
                          ],
                        );
                      if (rows.isEmpty)
                        return Card(
                          child: Padding(
                            padding: const EdgeInsets.all(20),
                            child: Text(switch (section) {
                              2 => 'مفيش طلبات جديدة.',
                              _ =>
                                messages.isEmpty
                                    ? 'استورد ملفات TXT من واتساب عشان تبدأ.'
                                    : 'مفيش نتائج تطابق الفلاتر.',
                            }),
                          ),
                        );
                      if (index > limit)
                        return OutlinedButton(
                          onPressed: () => setState(() => limit += 60),
                          child: const Text('عرض المزيد'),
                        );
                      final item = rows[index - 1];
                      return Card(
                        child: InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: () => showMessage(item),
                          child: Padding(
                            padding: const EdgeInsets.all(15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Row(
                                  children: [
                                    Icon(
                                      item.kind == 'offer'
                                          ? Icons.apartment
                                          : item.kind == 'request'
                                          ? Icons.person_search_outlined
                                          : Icons.chat_outlined,
                                      color: green,
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        item.kind == 'other'
                                            ? 'رسالة من ${item.sender}'
                                            : item.title,
                                        style: theme.textTheme.titleMedium
                                            ?.copyWith(
                                              fontWeight: FontWeight.bold,
                                            ),
                                      ),
                                    ),
                                    if (item.kind == 'request' && !item.seen)
                                      const Chip(
                                        label: Text('جديد'),
                                        visualDensity: VisualDensity.compact,
                                      ),
                                  ],
                                ),
                                if (item.details.price > 0 ||
                                    item.details.area > 0)
                                  Padding(
                                    padding: const EdgeInsets.only(top: 6),
                                    child: Text(
                                      item.details.summary,
                                      style: theme.textTheme.bodyMedium
                                          ?.copyWith(color: green),
                                    ),
                                  ),
                                const SizedBox(height: 8),
                                Text(
                                  item.body,
                                  maxLines: 3,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const Divider(),
                                Text(
                                  'مرسل من: ${item.sender}',
                                  style: theme.textTheme.bodySmall,
                                ),
                                Text(
                                  'المصدر: ${item.source}${item.historical ? ' · السجل' : ''}',
                                  style: theme.textTheme.bodySmall,
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
    );
  }
}

Future<List<Map<String, dynamic>>> _parseExportFile(
  (String, String) file,
) async => parseExport(
  utf8.decode(await File(file.$1).readAsBytes(), allowMalformed: true),
  file.$2,
);

class _MessageSheet extends StatefulWidget {
  const _MessageSheet({required this.item, required this.matches});
  final Message item;
  final List<Message> matches;
  @override
  State<_MessageSheet> createState() => _MessageSheetState();
}

class _MessageSheetState extends State<_MessageSheet> {
  late final Set<String> selected =
      widget.matches.take(3).map((row) => row.id).toSet();
  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    return SafeArea(
      child: FractionallySizedBox(
        heightFactor: .88,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 0, 18, 24),
          children: [
            Text(
              item.kind == 'other' ? 'تفاصيل الرسالة' : item.title,
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 10),
            Text('مرسل من: ${item.sender} · المصدر: ${item.source}'),
            if (item.date.isNotEmpty)
              Text(
                item.date,
                textDirection: TextDirection.ltr,
                textAlign: TextAlign.right,
              ),
            const SizedBox(height: 12),
            SelectableText(item.body),
            if (item.kind == 'request') ...[
              const SizedBox(height: 24),
              Text(
                'عروض مناسبة للعميل ${item.sender}',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              if (item.dismissed)
                TextButton(
                  onPressed: () => Navigator.pop(context, 'restore'),
                  child: const Text('اعرض الاقتراحات من جديد'),
                )
              else if (widget.matches.isEmpty)
                const Text('مفيش عروض توافق بيانات الطلب حاليًا.')
              else ...[
                for (final match in widget.matches)
                  CheckboxListTile(
                    value: selected.contains(match.id),
                    title: Text(match.title),
                    subtitle: Text(match.details.summary),
                    onChanged:
                        (value) => setState(
                          () =>
                              value == true
                                  ? selected.add(match.id)
                                  : selected.remove(match.id),
                        ),
                  ),
                Wrap(
                  spacing: 10,
                  children: [
                    FilledButton(
                      onPressed:
                          selected.isEmpty
                              ? null
                              : () {
                                final list = widget.matches
                                    .where((row) => selected.contains(row.id))
                                    .map((row) => '• ${row.details.summary}')
                                    .join('\n');
                                Navigator.pop(
                                  context,
                                  'أهلًا بك، معك الجودة العقارية. دي عروض قد تناسب طلبك:\n\n$list\n\nلو عرض يناسبك، رد علينا علشان نأكد توفره ونرسل لك التفاصيل.',
                                );
                              },
                      child: const Text('أرسل'),
                    ),
                    OutlinedButton(
                      onPressed: () => Navigator.pop(context, 'dismiss'),
                      child: const Text('لا ترسل'),
                    ),
                  ],
                ),
              ],
            ],
          ],
        ),
      ),
    );
  }
}

class _ReplyDialog extends StatefulWidget {
  const _ReplyDialog({required this.item, required this.text});
  final Message item;
  final String text;
  @override
  State<_ReplyDialog> createState() => _ReplyDialogState();
}

class _ReplyDialogState extends State<_ReplyDialog> {
  late final phone = TextEditingController(text: widget.item.phone);
  late final reply = TextEditingController(text: widget.text);
  @override
  void dispose() {
    phone.dispose();
    reply.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final number = digits(phone.text).replaceAll(RegExp(r'[+\s()-]'), '');
    final valid = RegExp(r'^[1-9]\d{7,14}$').hasMatch(number);
    return AlertDialog(
      title: Text('رسالة للعميل ${widget.item.sender}'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: phone,
              keyboardType: TextInputType.phone,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(
                labelText: 'رقم واتساب بصيغة دولية',
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: reply,
              maxLines: 7,
              decoration: const InputDecoration(labelText: 'نص الرد'),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () async {
            await Clipboard.setData(ClipboardData(text: reply.text));
            if (context.mounted)
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(const SnackBar(content: Text('تم نسخ الرد')));
          },
          child: const Text('نسخ الرد'),
        ),
        FilledButton(
          onPressed:
              !valid
                  ? null
                  : () async {
                    final url = Uri.https('wa.me', '/$number', {
                      'text': reply.text,
                    });
                    if (!await launchUrl(
                          url,
                          mode: LaunchMode.externalApplication,
                        ) &&
                        context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('تعذر فتح واتساب')),
                      );
                    }
                  },
          child: const Text('فتح في واتساب'),
        ),
      ],
    );
  }
}
