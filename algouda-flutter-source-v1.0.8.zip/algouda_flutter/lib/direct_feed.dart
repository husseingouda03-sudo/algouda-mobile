import 'package:flutter/material.dart';

import 'messages.dart';
import 'repository.dart';

const riyadhZones = [
  'كل الرياض',
  'شمال الرياض',
  'شرق الرياض',
  'غرب الرياض',
  'جنوب الرياض',
  'غير محدد',
];
const residenceTypes = ['فيلا', 'أرض', 'شقة', 'دور', 'فيلا بقيمة أرض'];
const industrialTypes = ['أرض صناعية', 'مستودع'];
const offerTypes = [...residenceTypes, ...industrialTypes];
const dealTypes = ['بيع', 'إيجار'];
const feedPlatforms = ['عقار', 'حراج', 'ديل', 'بيوت'];
const advertiserRoles = [
  'يذكر أنه المالك',
  'يذكر أنه وكيل مباشر',
  'مرجّح أنه مالك',
  'غير متحقق من التنبيه',
];
String? _feedPlatform(Uri link) {
  if (link.scheme != 'https' || link.userInfo.isNotEmpty || link.hasPort)
    return null;
  const platforms = {
    'aqar.fm': 'عقار',
    'haraj.com.sa': 'حراج',
    'dealapp.sa': 'ديل',
    'wasalt.sa': 'وصلت',
    'wasalt.com': 'وصلت',
    'bayut.sa': 'بيوت',
  };
  for (final entry in platforms.entries) {
    if (link.host == entry.key || link.host.endsWith('.${entry.key}'))
      return entry.value;
  }
  return null;
}

Uri? feedUri(String value) {
  final uri = Uri.tryParse(value.trim());
  return uri != null &&
          uri.scheme == 'https' &&
          uri.host.isNotEmpty &&
          uri.userInfo.isEmpty &&
          !uri.hasQuery &&
          !uri.hasFragment
      ? uri
      : null;
}

List<Map<String, dynamic>> parseDirectOffers(Object? data) {
  if (data is! List || data.length > 400) throw const FormatException('offers');
  final result = <Map<String, dynamic>>[];
  final urls = <String>{};
  for (final raw in data) {
    if (raw is! Map<String, dynamic>) continue;
    final uri = Uri.tryParse(raw['url'] is String ? raw['url'] as String : '');
    if (uri == null ||
        uri.scheme != 'https' ||
        _feedPlatform(uri) == null ||
        uri.userInfo.isNotEmpty ||
        uri.hasPort ||
        uri.hasFragment ||
        !feedPlatforms.contains(raw['platform']) ||
        !riyadhZones.contains(raw['zone']) ||
        !offerTypes.contains(raw['type']) ||
        !dealTypes.contains(raw['deal']) ||
        !advertiserRoles.contains(raw['role']) ||
        raw['title'] is! String ||
        raw['district'] is! String ||
        raw['notes'] is! String ||
        !urls.add(uri.toString())) {
      continue;
    }
    result.add({
      for (final key in [
        'title',
        'district',
        'zone',
        'type',
        'deal',
        'role',
        'role_reason',
        'platform',
        'notes',
      ])
        key: raw[key],
      'url': uri.toString(),
    });
  }
  return result;
}

class DirectFeed extends ChangeNotifier {
  DirectFeed(this.repository);
  final Repository repository;
  List<Map<String, dynamic>> offers = [];
  Uri? url;
  bool busy = false, _disposed = false;
  String status = 'المزامنة غير مفعّلة';

  Future<void> start() async {
    url = null;
    if (_disposed) return;
    notifyListeners();
    await refresh();
  }

  Future<void> refresh() async {
    if (busy || _disposed) return;
    busy = true;
    status = 'جاري قراءة تنبيهات تطبيقات العقار المحفوظة على الهاتف';
    notifyListeners();
    try {
      final index = await repository.messages();
      final next = <Map<String, dynamic>>[];
      final seen = <String>{};
      for (final message in index.offers) {
        if (!message.source.startsWith('تنبيه ')) continue;
        final source = message.source.replaceFirst('تنبيه ', '');
        final urlMatch = RegExp(r'https://[^\s]+').firstMatch(message.body);
        final link = urlMatch?.group(0) ?? '';
        final uri = Uri.tryParse(link);
        final platform = uri == null ? source : _feedPlatform(uri) ?? source;
        final place = message.details.place;
        final zone = _zoneFor(place);
        final identity = '${message.date}|${message.body}|$source';
        if (!seen.add(identity)) continue;
        next.add({
          'title': message.title,
          'district': place == unknownPlace ? '' : place,
          'zone': zone,
          'type':
              offerTypes.contains(message.details.type)
                  ? message.details.type
                  : 'عقار',
          'deal':
              dealTypes.contains(message.details.intent)
                  ? message.details.intent
                  : 'بيع',
          'role': 'غير متحقق من التنبيه',
          'role_reason': 'تنبيه من المنصة؛ افتح الإعلان وتأكد من صفة المعلن.',
          'platform': platform,
          'notes': message.body,
          'url': link,
        });
      }
      if (_disposed) return;
      offers = next;
      status =
          offers.isEmpty
              ? 'مفيش تنبيهات عقارية محفوظة لسه. فعّل تنبيهات البحث في تطبيقات العقار.'
              : 'تم فرز ${offers.length} تنبيه عقاري من الهاتف';
    } catch (_) {
      status = 'تعذر قراءة التنبيهات المحفوظة على الهاتف';
    } finally {
      busy = false;
      if (!_disposed) notifyListeners();
    }
  }

  Future<void> configure(BuildContext context) async {
    await showDialog<void>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('مصدر العروض بدون Kite'),
            content: const Text(
              'التطبيق يقرأ محليًا تنبيهات حراج وعقار وبيوت ووصلت وديل الظاهرة على الهاتف بعد تفعيل إذن الإشعارات. فعّل تنبيه البحث داخل كل منصة. إذا كان التنبيه مختصرًا، افتح الإعلان وسجّل تفاصيله من زر «إضافة عرض». لا يجمع التطبيق إعلانات لم ترسل المنصة عنها تنبيهًا.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('إغلاق'),
              ),
            ],
          ),
    );
  }

  String _zoneFor(String place) {
    const north = [
      'النرجس',
      'الياسمين',
      'الملقا',
      'الصحافة',
      'العقيق',
      'حطين',
      'القيروان',
      'النخيل',
      'العارض',
      'الغدير',
      'الوادي',
      'الفلاح',
      'الازدهار',
      'المروج',
      'المصيف',
      'التعاون',
      'النفل',
      'الربيع',
    ];
    const east = [
      'قرطبة',
      'اليرموك',
      'إشبيلية',
      'اشبيلية',
      'الخليج',
      'الرمال',
      'المونسية',
      'النسيم',
      'الروضة',
      'النهضة',
      'القادسية',
      'الجنادرية',
    ];
    const west = [
      'ظهرة لبن',
      'لبن',
      'السويدي',
      'طويق',
      'العريجاء',
      'نمار',
      'الحزم',
      'شبرا',
      'عرقة',
      'المهدية',
    ];
    const south = [
      'الشفا',
      'العزيزية',
      'بدر',
      'الدار البيضاء',
      'المنصورة',
      'الصناعية',
      'السعادة',
      'المناخ',
      'المصانع',
    ];
    if (north.contains(place)) return 'شمال الرياض';
    if (east.contains(place)) return 'شرق الرياض';
    if (west.contains(place)) return 'غرب الرياض';
    if (south.contains(place)) return 'جنوب الرياض';
    return 'غير محدد';
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}
