const unknownPlace = 'موقع غير محدد';
const districts = [
  'اليرموك',
  'الرمال',
  'المونسية',
  'قرطبة',
  'إشبيلية',
  'الياسمين',
  'النرجس',
  'الفاروق',
  'ظهرة لبن',
  'الملقا',
  'القيروان',
  'العارض',
  'الربوة',
  'النسيم',
  'الوادي',
  'الرحمانية',
  'المروج',
  'عرقة',
  'الفيصلية',
  'الملك فيصل',
  'الصحافة',
  'العقيق',
  'حطين',
  'الروضة',
  'الشفا',
  'العوالي',
  'السويدي',
  'طويق',
  'العريجاء',
  'نمار',
  'الندوة',
  'النهضة',
  'النخيل',
  'الغدير',
  'الفلاح',
  'الازدهار',
  'المصيف',
  'التعاون',
  'النفل',
  'الربيع',
  'الخليج',
  'لبن',
];
const cities = [
  'الرياض',
  'جدة',
  'الدمام',
  'الخبر',
  'مكة',
  'المدينة المنورة',
  'القاهرة',
  'الجيزة',
  'المنيا',
  'مغاغة',
];
final _markers = RegExp(
  r'[\u061c\u200e\u200f\u202a-\u202e\u2066-\u2069\ufeff]',
);
String digits(String value) => value.replaceAllMapped(
  RegExp('[٠-٩۰-۹]'),
  (match) => (match[0]!.codeUnitAt(0) % 16).toString(),
);
String normalize(String value) => digits(value)
    .toLowerCase()
    .replaceAll(_markers, '')
    .replaceAll(RegExp(r'[\u064b-\u065fـ]'), '')
    .replaceAll(RegExp('[أإآ]'), 'ا')
    .replaceAll('ة', 'ه')
    .replaceAll('ى', 'ي');

final _areaMatchers = [
  for (final area in [...districts, ...cities])
    (
      area,
      RegExp(
        r'(?:^|[^\p{L}\p{N}])(?:ب)?' +
            RegExp.escape(normalize(area)) +
            r'(?=$|[^\p{L}\p{N}])',
        unicode: true,
      ),
    ),
];

String textOf(Map<String, dynamic> map, String key) =>
    map[key] is String ? map[key] as String : '';

class Criteria {
  const Criteria({
    required this.place,
    required this.type,
    required this.intent,
    required this.price,
    required this.currency,
    required this.area,
    required this.rooms,
  });
  final String place, type, intent, currency;
  final num price, area, rooms;
  bool get useful =>
      place != unknownPlace ||
      type.isNotEmpty ||
      intent.isNotEmpty ||
      price > 0 ||
      area > 0 ||
      rooms > 0;

  String get summary => [
    type,
    intent,
    if (place != unknownPlace) place,
    if (price > 0)
      [
        price.toStringAsFixed(price % 1 == 0 ? 0 : 2),
        currency,
      ].where((item) => item.isNotEmpty).join(' '),
    if (area > 0) '${area.toStringAsFixed(area % 1 == 0 ? 0 : 2)} م²',
    if (rooms > 0) '$rooms غرف',
  ].where((part) => part.isNotEmpty).join(' · ');
}

final _property = RegExp(
  r'فيلا|فله|شقق|شقه|ارض|عماره|(?:^|\s)دور(?=\s|$)|دبلكس|محل|استراحه|بيت|مكتب|مستودع|عقار|سكن',
);
const _types = {
  'فله': 'فيلا',
  'شقق': 'شقة',
  'شقه': 'شقة',
  'ارض': 'أرض',
  'عماره': 'عمارة',
  'استراحه': 'استراحة',
};
final _request = RegExp(
  r'(?:^|[^\p{L}\p{N}])(?:مطلوب|ابحث عن|يدور على|احتاج|ابي|ابغي|عايزه?|بدور على|ادور على|لو في|ممكن الاقي|متوفر عندكم|عندكم|نبحث عن|عندي عميل|عميل يبي|عميل عايز|عندي طلب|نحتاج)(?=$|[^\p{L}\p{N}])',
  unicode: true,
);
final _offer = RegExp('للبيع|للايجار|للاستثمار|معروض|عرض عقاري|متوفر|حد البيع');
const _number = r'\d+(?:[.,٬٫]\d+)*';
final _amount =
    r'(?:' +
    _number +
    r'\s*)?مليون(?:ين|\s*و\s*(?:نص(?:ف)?|' +
    _number +
    r'\s*(?:الاف|الف)))?|' +
    _number +
    r'\s*(?:الاف|الف)?';
num _numberValue(String? value) =>
    num.tryParse(
      (value ?? '').replaceAll(RegExp('[٬,]'), '').replaceAll('٫', '.'),
    ) ??
    0;

num _price(String text) {
  final money =
      RegExp(
        r'(?:حد اقصي|بحدود|بميزانيه|الميزانيه|ميزانيه|ميزانيته|بحد|في حدود|تحت|اقل من|لحد|حتي|السعر|بسعر|حد البيع)\s*[:：]?\s*(' +
            _amount +
            r')(?![\p{L}\p{N}])',
        unicode: true,
      ).firstMatch(text)?[1] ??
      RegExp('(' + _amount + r')\s*(?:ريال|جنيه)').firstMatch(text)?[1] ??
      RegExp(
        r'(?:' +
            _number +
            r'\s*)?مليون(?:ين|\s*و\s*(?:نص(?:ف)?|' +
            _number +
            r'\s*(?:الاف|الف)))?|' +
            _number +
            r'\s*(?:الاف|الف)',
      ).firstMatch(text)?[0] ??
      '';
  if (money.contains('مليونين')) return 2000000;
  if (money.contains('مليون')) {
    final leading = RegExp('^(' + _number + r')\s*مليون').firstMatch(money)?[1];
    final tail =
        RegExp(
          r'مليون\s*و\s*(' + _number + r')\s*(?:الاف|الف)',
        ).firstMatch(money)?[1];
    return (leading == null ? 1 : _numberValue(leading)) * 1000000 +
        (tail != null
            ? _numberValue(tail) * 1000
            : RegExp(r'مليون\s*و\s*نص').hasMatch(money)
            ? 500000
            : 0);
  }
  return _numberValue(RegExp(_number).firstMatch(money)?[0]) *
      (money.contains('الف') || money.contains('الاف') ? 1000 : 1);
}

Criteria criteria(String body, [Map<String, dynamic> hints = const {}]) =>
    _criteria(body, normalize(body), hints);

Criteria _criteria(String body, String text, Map<String, dynamic> hints) {
  String hint(String key, String fallback) =>
      textOf(hints, key).isEmpty ? fallback : textOf(hints, key);
  final property = _property.firstMatch(text)?[0]?.trim() ?? '';
  var place = unknownPlace;
  for (final (area, matcher) in _areaMatchers) {
    if (matcher.hasMatch(text)) {
      place = area;
      break;
    }
  }
  if (place == unknownPlace) {
    final match =
        RegExp(
          r'(?:^|\s)(?:ب?حي|منطقة|الموقع)\s*[:：]?\s+([\p{L}]+(?:\s+[\p{L}]+){0,3})',
          unicode: true,
        ).firstMatch(body)?[1];
    if (match != null) {
      place =
          match
              .split(
                RegExp(
                  r'\s+(?=مساح[هة]|شارع|واجه[هة]|بال?قرب|خلف|سعر|في|على|تتكون|بسعر|جديد)',
                ),
              )
              .first;
    }
  }
  final intent =
      RegExp('ايجار|استئجار|استاجر|اجار').hasMatch(text)
          ? 'إيجار'
          : RegExp('بيع|شراء|تمليك|اشتري').hasMatch(text)
          ? 'بيع'
          : '';
  return Criteria(
    place: hint('place', place),
    type: hint('type', _types[property] ?? property),
    intent: hint('intent', intent),
    price: _price(text),
    currency:
        text.contains('ريال')
            ? 'ريال'
            : text.contains('جنيه')
            ? 'جنيه'
            : '',
    area: _numberValue(
      RegExp(
        r'(\d+(?:[.٫]\d+)?)\s*(?:متر(?:\s+مربع)?|م[²2])',
      ).firstMatch(text)?[1],
    ),
    rooms: _numberValue(RegExp(r'(\d+)\s*غرف').firstMatch(text)?[1]),
  );
}

class Message {
  Message(this.data);
  final Map<String, dynamic> data;
  late final Criteria details = _criteria(body, _normalizedBody, {
    ...data,
    if (data['analysis'] is Map)
      ...Map<String, dynamic>.from(data['analysis'] as Map),
  });
  String get id => textOf(data, 'id');
  String get body => textOf(data, 'body');
  String get source => textOf(data, 'source');
  String get groupId => textOf(data, 'groupId');
  String get sender => textOf(data, 'sender');
  String get date => textOf(data, 'date');
  bool get historical => data['historical'] == true;
  bool get seen => data['seen'] == true || historical;
  bool get dismissed => data['dismissed'] == true;
  String get phone =>
      textOf(data, 'phone').isNotEmpty
          ? textOf(data, 'phone')
          : RegExp(r'^\+?[\d\s-]{10,22}$').hasMatch(digits(sender))
          ? digits(sender).replaceAll(RegExp(r'\D'), '')
          : '';
  late final String _normalizedBody = normalize(body);
  late final String kind = _classify();
  late final String searchableText = normalize(
    '$body $sender $source ${details.place} $title',
  );

  String _classify() {
    final remote =
        data['analysis'] is Map ? (data['analysis'] as Map)['kind'] : null;
    final platformPropertyAlert =
        source.startsWith('تنبيه ') && _property.hasMatch(_normalizedBody);
    final kind =
        const ['offer', 'request', 'other'].contains(remote)
            ? remote as String
            : _request.hasMatch(_normalizedBody) &&
                (details.type.isNotEmpty || _offer.hasMatch(_normalizedBody))
            ? 'request'
            : _offer.hasMatch(_normalizedBody) || platformPropertyAlert
            ? 'offer'
            : 'other';
    return data['outgoing'] == true && kind == 'request' ? 'other' : kind;
  }

  String get title => [
    details.type.isEmpty ? 'عقار' : details.type,
    details.intent,
    if (details.place != unknownPlace) details.place,
  ].where((item) => item.isNotEmpty).join(' · ');
  Message update(Map<String, dynamic> changes) =>
      Message({...data, ...changes});
}

final _stamp = RegExp(
  r'^(?:\[(\d{1,4}[/.\-]\d{1,2}[/.\-]\d{1,4})[,،]?\s+(\d{1,2}:\d{2}(?::\d{2})?(?:\s*(?:[ap]\.?m\.?|[صم]|صباح[ً]?ا|مساء[ً]?))?)\]\s*|(\d{1,4}[/.\-]\d{1,2}[/.\-]\d{1,4})[,،]?\s+(\d{1,2}:\d{2}(?::\d{2})?(?:\s*(?:[ap]\.?m\.?|[صم]|صباح[ً]?ا|مساء[ً]?))?)\s+[–—-]\s*)',
  caseSensitive: false,
);
final _person = RegExp(r'^([^:：\n]{1,100})[:：]\s?(.*)$');

List<Map<String, dynamic>> parseExport(
  String raw,
  String source, {
  String sender = '',
}) {
  final messages = <Map<String, dynamic>>[];
  Map<String, dynamic>? current;
  var stamped = false;
  for (final line in raw.replaceAll(_markers, '').split(RegExp(r'\r?\n'))) {
    final stamp = _stamp.firstMatch(digits(line));
    if (stamp == null) {
      if (current != null) current['body'] = '${current['body']}\n$line';
      continue;
    }
    stamped = true;
    if (current != null) messages.add(current);
    final person = _person.firstMatch(line.substring(stamp.end));
    current =
        person == null
            ? null
            : {
              'source': source,
              'sender': person[1]!.trim(),
              'date': '${stamp[1] ?? stamp[3]} ${stamp[2] ?? stamp[4]}',
              'body': person[2]!,
            };
  }
  if (current != null) messages.add(current);
  if (!stamped && raw.trim().isNotEmpty) {
    messages.add({
      'source': source,
      'sender': sender.isEmpty ? 'غير معروف' : sender,
      'date': '',
      'body': raw.trim(),
    });
  }
  return messages
      .where((message) => textOf(message, 'body').trim().isNotEmpty)
      .map((message) => {...message, 'body': textOf(message, 'body').trim()})
      .toList();
}

List<Message> suggestions(Iterable<Message> offers, Criteria query) {
  final scored = <(Message, int)>[];
  for (final row in offers) {
    final found = row.details;
    if (query.place != unknownPlace &&
        normalize(found.place) != normalize(query.place))
      continue;
    if (query.type.isNotEmpty &&
        found.type.isNotEmpty &&
        query.type != found.type)
      continue;
    if (query.intent.isNotEmpty &&
        found.intent.isNotEmpty &&
        query.intent != found.intent)
      continue;
    if (query.currency.isNotEmpty &&
        found.currency.isNotEmpty &&
        query.currency != found.currency)
      continue;
    if (query.price > 0 && found.price > query.price) continue;
    if (query.area > 0 && found.area > 0 && found.area < query.area) continue;
    if (query.rooms > 0 && found.rooms > 0 && found.rooms < query.rooms)
      continue;
    final score =
        [
          query.place != unknownPlace,
          query.type.isNotEmpty && query.type == found.type,
          query.intent.isNotEmpty && query.intent == found.intent,
          query.price > 0 && found.price > 0,
          query.area > 0 && found.area > 0,
          query.rooms > 0 && found.rooms > 0,
        ].where((match) => match).length;
    if (score > 0) scored.add((row, score));
  }
  scored.sort((left, right) => right.$2.compareTo(left.$2));
  return scored.map((item) => item.$1).toList();
}
