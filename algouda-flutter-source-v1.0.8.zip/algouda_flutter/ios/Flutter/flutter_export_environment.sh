#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/workspace/scratch/500796d99b74/startup-sdk/flutter"
export "FLUTTER_APPLICATION_PATH=/workspace/scratch/500796d99b74/flutter-source/extracted/algouda_flutter"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.7"
export "FLUTTER_BUILD_NUMBER=8"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
