import 'package:algouda_real_estate/messages.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('استيراد تصدير عربي متعدد الأسطر مع المرسل والمصدر', () {
    final messages =
        parseExport(
          '٢٤/١١/٢٠٢٦، ٩:١٥ ص - أحمد: للبيع دور مساحة 500 متر في حي اليرموك\nواجهة جنوبية\n'
              '[24/11/26, 9:19:26 AM] منى: مطلوب دور للبيع في اليرموك بميزانية مليون ونص ريال',
          'عروض اليرموك',
        ).map(Message.new).toList();
    expect(messages, hasLength(2));
    expect(messages.first.sender, 'أحمد');
    expect(messages.first.source, 'عروض اليرموك');
    expect(messages.first.body, contains('واجهة جنوبية'));
    expect(messages.first.kind, 'offer');
    expect(messages.first.details.place, 'اليرموك');
    expect(messages.first.details.area, 500);
    expect(messages.last.kind, 'request');
    expect(messages.last.details.price, 1500000);
  });

  test('مطابقة نوع العقار والحي والميزانية', () {
    final offers = [
      Message({'body': 'للبيع فيلا في الرمال السعر مليون و 200 ألف ريال'}),
      Message({'body': 'للبيع فيلا في الرمال السعر ٢ مليون ريال'}),
      Message({'body': 'للبيع فيلا في اليرموك السعر مليون ريال'}),
    ];
    final request = criteria('عايز فيلا للبيع في الرمال بحدود مليون ونص ريال');
    expect(suggestions(offers, request), [offers.first]);
    expect(offers.first.details.price, 1200000);
  });

  test('سجل واتساب لا يولد تنبيه للطلبات القديمة أو الصادرة', () {
    final row = {'body': 'مطلوب شقة في حي قرطبة', 'historical': true};
    expect(Message(row).kind, 'request');
    expect(Message(row).seen, true);
    expect(Message({...row, 'outgoing': true}).kind, 'other');
  });
}
