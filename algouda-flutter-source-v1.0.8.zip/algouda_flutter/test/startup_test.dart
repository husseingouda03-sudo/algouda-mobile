import 'dart:async';
import 'dart:convert';
import 'package:algouda_real_estate/main.dart';
import 'package:algouda_real_estate/repository.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Offers retain their group identity and sender', () {
    Map<String, Object?> row(String body, String sender, String group) => {
      'data': jsonEncode({
        'body': body,
        'sender': sender,
        'source': group.isEmpty ? 'محادثة خاصة' : 'عقارات الرياض',
        'groupId': group,
      }),
    };
    final index = decodeMessageIndex([
      row('للبيع فيلا في الياسمين', 'أحمد', 'group-one'),
      row('للبيع شقة في اليرموك', 'محمد', 'group-two'),
      row('للبيع أرض في الرمال', 'محمود', ''),
      row('مطلوب شقة في قرطبة', 'علي', 'group-three'),
    ]);

    expect(index.offerGroups, {
      'group-one': 'عقارات الرياض',
      'group-two': 'عقارات الرياض',
    });
    expect(index.offers.map((offer) => offer.sender), [
      'أحمد',
      'محمد',
      'محمود',
    ]);
    expect(index.fresh.single.sender, 'علي');
  });

  testWidgets('Shows the first frame and handles a stalled database', (
    tester,
  ) async {
    const sqlite = MethodChannel('com.tekartik.sqflite');
    final stalled = Completer<String>();
    final messenger = tester.binding.defaultBinaryMessenger;
    messenger.setMockMethodCallHandler(sqlite, (_) => stalled.future);
    addTearDown(() => messenger.setMockMethodCallHandler(sqlite, null));

    await tester.pumpWidget(const AlgoudaApp());
    expect(find.text('الجودة العقارية'), findsOneWidget);
    await tester.pump(const Duration(seconds: 9));
    await tester.pump();
    expect(find.text('تعذر فتح مخزن الرسائل على الجهاز.'), findsOneWidget);
  });
}
