import 'package:algouda_real_estate/direct_feed.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Imports distinct owner offers and keeps the deal and type', () {
    final listing = <String, dynamic>{
      'title': 'دور للإيجار في العارض',
      'district': 'العارض',
      'zone': 'شمال الرياض',
      'type': 'دور',
      'deal': 'إيجار',
      'platform': 'عقار',
      'role': 'المالك بحسب الإعلان',
      'url': 'https://kite.sa/en/listing/42',
      'notes': '50,000 ريال سنويًا',
      'phone': '0500000000',
    };
    final offers = parseDirectOffers([
      listing,
      listing,
      {...listing, 'url': 'https://kite.sa.evil.example/en/listing/43'},
      {...listing, 'url': 'https://kite.sa/en/listing/44', 'role': 'وسيط'},
      {
        ...listing,
        'url': 'https://kite.sa/en/listing/45',
        'zone': 'وسط الرياض',
      },
    ]);
    expect(offers, hasLength(1));
    expect(offers.single['deal'], 'إيجار');
    expect(offers.single['type'], 'دور');
    expect(offers.single.containsKey('phone'), isFalse);
  });
}
